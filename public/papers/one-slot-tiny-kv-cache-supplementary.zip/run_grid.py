"""Grid runner: capacity x protection fraction x policy, at tiny cache sizes.

Readouts
--------
nll : mean NLL of the gold answer (<= opt-tokens), continuous, cheap  [primary]
mc  : 4-way multiple choice over gold + 3 distractors                  [validation]

Writes one JSON object per (item, C, rho, policy), flushed per item.
Re-running skips rows already present; a failing item does not kill the run.
"""
import argparse, json, math, os, sys, time
import torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness as H

DATA = "/root/.hermes/profiles/sidequests/cache/scratch/lbdata/data"


def exact_prefix_tokens(tok, text, marker="Question:"):
    q = text.rfind(marker)
    if q <= 0:
        return -1, False
    pre = tok(text[:q], add_special_tokens=False).input_ids
    full = tok(text, add_special_tokens=False).input_ids
    return len(pre), full[:len(pre)] == pre


def run_item(m, tok, items, ii, it, key, a, budgets, rhos, policies, f, done):
    t0 = time.time()
    ids, text = H.build_prompt(tok, it, a.ctx)
    L = int(ids.shape[1])
    q_tok, exact = exact_prefix_tokens(tok, text)
    struct_span = (L - q_tok) if q_tok > 0 else -1
    opts, opt_ids = H.make_options(tok, items, ii, k=a.n_options, max_opt_tokens=a.opt_tokens)
    opt_ids = opt_ids if a.readout == "mc" else opt_ids[:1]

    cache, attn_tuple, first_logits = H.prefill(m, ids)
    Lw = min(32, L)
    acc_all = torch.zeros(L); acc_obs = torch.zeros(L); acc_last = torch.zeros(L)
    nl = len(attn_tuple)
    for a_ in attn_tuple:
        a_ = a_.clamp(min=0)                      # [H, L, L]
        acc_all += a_.sum(dim=1).sum(dim=0)
        acc_obs += a_[:, L - Lw:, :].sum(dim=1).sum(dim=0)
        acc_last += a_[:, -1, :].sum(dim=0)
    del attn_tuple
    scores = {"h2o": acc_all / nl, "recv_all": acc_all / nl, "snapkv": acc_obs / nl,
              "recv_obs": acc_obs / nl, "quest": acc_last / nl,
              "lru": torch.arange(L, dtype=torch.float32)}

    mass = H.dense_answer_attention(m, cache, L, opt_ids)
    if mass is None:
        # 1-token answer: its attention is the last prompt query row, already accumulated.
        mass = (acc_last / nl).clone()
    mtot = float(mass.sum())
    dense_lp, _ = H.option_logprobs(m, cache, L, first_logits, opt_ids)
    meta = {"item_key": key, "task": it["task"], "L": L, "struct_span": struct_span,
            "prefix_exact": bool(exact), "n_options": len(dense_lp),
            "n_ans_tokens": len(opt_ids[0]), "ground_truth": it["answers"][0],
            "options": opts[:len(dense_lp)]}
    f.write(json.dumps({**meta, "C": -1, "rho": 0.0, "policy": "dense",
                        "logprobs": dense_lp, "mass_retained": 1.0,
                        "mass_total": mtot, "n_kept": L, "n_protected": 0}) + "\n")

    seen = {}
    for C in budgets:
        for rho in rhos:
            k_side = min(int(math.ceil(rho * C)) if rho > 0 else 0, C // 2)
            for pol in policies:
                if (key, C, rho, pol) in done:
                    continue
                if pol == "oracle":
                    idx = torch.sort(torch.argsort(-mass)[:C]).values
                else:
                    idx = H.retained_set(pol, L, C, rho, scores, seed=a.seed, min_side=a.min_side)
                sig = tuple(idx.tolist())
                if sig not in seen:
                    seen[sig] = H.option_logprobs(m, cache, L, first_logits, opt_ids, idx=idx)[0]
                lp = seen[sig]
                kept = idx.tolist()
                nprot = sum(1 for i in kept if i < k_side or i >= L - k_side)
                f.write(json.dumps({
                    **{k: meta[k] for k in ("item_key", "task", "L", "struct_span",
                                            "n_options", "n_ans_tokens")},
                    "C": C, "rho": rho, "policy": pol, "logprobs": lp,
                    "mass_retained": float(mass[idx].sum() / mtot),
                    "mass_total": mtot, "n_kept": int(len(idx)),
                    "n_protected": nprot}) + "\n")
    f.flush(); os.fsync(f.fileno())
    print(f"[{ii+1}/{len(items)}] {key[:22]} L={L} struct={struct_span} tok={len(opt_ids[0])} "
          f"uniq={len(seen)} {time.time()-t0:.1f}s", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen2.5-0.5B-Instruct")
    ap.add_argument("--tag", default="q05")
    ap.add_argument("--tasks", default="2wikimqa,qasper,multifieldqa_en,hotpotqa")
    ap.add_argument("--n", type=int, default=8)
    ap.add_argument("--ctx", type=int, default=1000)
    ap.add_argument("--budgets", default="8,16,32,64,128,256")
    ap.add_argument("--rhos", default="0,0.05,0.1,0.2,0.3,0.5")
    ap.add_argument("--policies", default="lru,h2o,snapkv,random,slw,oracle")
    ap.add_argument("--min-side", type=int, default=0)
    ap.add_argument("--readout", default="nll", choices=["nll", "mc"])
    ap.add_argument("--opt-tokens", type=int, default=4)
    ap.add_argument("--n-options", type=int, default=4)
    ap.add_argument("--out", default=None)
    ap.add_argument("--limit-items", type=int, default=0)
    ap.add_argument("--skip-items", type=int, default=0)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()

    out = a.out or f"./results/{a.tag}.jsonl"
    os.makedirs(os.path.dirname(out), exist_ok=True)
    done = set()
    if os.path.exists(out):
        for line in open(out):
            try:
                r = json.loads(line)
                done.add((r["item_key"], r["C"], r["rho"], r["policy"]))
            except Exception:
                pass
    print(f"resume: {len(done)} rows", flush=True)

    items = H.load_items(a.tasks.split(","), a.n, DATA, seed=a.seed)
    if a.skip_items:
        items = items[a.skip_items:]
    if a.limit_items:
        items = items[:a.limit_items]
    budgets = [int(x) for x in a.budgets.split(",")]
    rhos = [float(x) for x in a.rhos.split(",")]
    policies = a.policies.split(",")

    m, tok = H.load_model(a.model)
    cfg = m.config
    S = cfg.num_hidden_layers * cfg.num_key_value_heads
    print(f"model {a.model} layers={cfg.num_hidden_layers} kv={cfg.num_key_value_heads} "
          f"S_streams={S} | items={len(items)} ctx<={a.ctx} readout={a.readout}", flush=True)

    f = open(out, "a")
    t_start = time.time()
    for ii, it in enumerate(items):
        key = f"{it['task']}/{it['id']}"
        if all((key, c, r, p) in done for c in budgets for r in rhos for p in policies):
            continue
        try:
            run_item(m, tok, items, ii, it, key, a, budgets, rhos, policies, f, done)
        except Exception as ex:
            import traceback
            print(f"!! item {key} failed: {type(ex).__name__}: {ex}", flush=True)
            traceback.print_exc()
            try:
                f.flush(); os.fsync(f.fileno())
            except Exception:
                pass
        tot = time.time() - t_start
        eta = tot / (ii + 1) * (len(items) - ii - 1)
        print(f"   elapsed {tot/60:.1f}m ETA {eta/60:.1f}m", flush=True)
    f.close()
    print("done ->", out, flush=True)


if __name__ == "__main__":
    main()
