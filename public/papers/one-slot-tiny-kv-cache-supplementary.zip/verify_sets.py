"""Verify the retention-set arithmetic behind the one-slot claim, with no model involved."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness as H
import torch

L = 1000
scores = {k: torch.arange(L, dtype=torch.float32) for k in ("h2o", "snapkv", "lru", "quest")}

def show(pol, C, rho):
    idx = H.retained_set(pol, L, C, rho, scores, seed=7).tolist()
    rngs, start = [], idx[0]
    for i in range(1, len(idx) + 1):
        if i == len(idx) or idx[i] != idx[i - 1] + 1:
            rngs.append((start, idx[i - 1])); start = idx[i] if i < len(idx) else None
    pretty = ", ".join(f"{a}" if a == b else f"{a}..{b}" for a, b in rngs)
    return set(idx), pretty

print("C=8, LRU, rho=0.0   ->", show("lru", 8, 0.0)[1])
print("C=8, LRU, rho=0.05  ->", show("lru", 8, 0.05)[1])
print("C=8, LRU, rho=0.10  ->", show("lru", 8, 0.10)[1])
print("C=8, SLW            ->", show("slw", 8, 0.0)[1])
print("C=8, LRU, rho=0.50  ->", show("lru", 8, 0.50)[1])
a = show("lru", 8, 0.0)[0]; b = show("lru", 8, 0.05)[0]
print("\nsymmetric difference  LRU@0  vs  LRU@0.05 :", sorted(a ^ b))
print("  removed:", sorted(a - b), " added:", sorted(b - a))
c = show("slw", 8, 0.0)[0]; d = show("lru", 8, 0.5)[0]
print("\nSLW set == LRU@rho=0.5 set ?", c == d, sorted(c))
print("\ncap behaviour: min(k, C//2) merges rho>=0.5:")
for rho in (0.4, 0.5, 0.8, 1.0):
    print(f"  C=8 rho={rho} -> k={len(H.protected_indices(8, 8, rho)[0])} per side")
print("\nquantisation of ceil(rho*C) at tiny C:")
for C in (8, 16, 32, 64, 256):
    print(f"  C={C:3d} " + " ".join(f"{r}:{len(H.protected_indices(C, C, r)[0])}"
                                    for r in (0.05, 0.1, 0.2, 0.3, 0.5)))
