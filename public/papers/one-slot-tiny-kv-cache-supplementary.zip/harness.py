"""Minimum-viable-protection harness for KV-cache eviction at tiny capacities.

Design
------
For each item: (1) prefill the full prompt once with eager attention; (2) read the
prefill attention to compute every policy's importance scores; (3) for each
(capacity C, protection fraction rho, policy) build a retained POSITION SET shared by
all layers and KV heads ("globally capped" accounting, as in 2605.18053); (4) slice
the KV cache to that set and teacher-force-score candidate answers.

Why slicing is exact: Qwen stores keys already rotated by their absolute positions, so
removing entries only removes attention *mass*; surviving entries keep their rotary
phase and the query keeps its absolute position id. Verified against a 4-D additive
mask forward and against a from-scratch full forward (verify.py).
"""
import json, math, os, random
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.cache_utils import DynamicCache

torch.set_num_threads(2)

# ---------------------------------------------------------------- model / data
def load_model(mid="Qwen/Qwen2.5-0.5B-Instruct"):
    tok = AutoTokenizer.from_pretrained(mid)
    m = AutoModelForCausalLM.from_pretrained(mid, dtype=torch.float32,
                                             attn_implementation="eager").eval()
    return m, tok

def load_items(tasks, n_per_task, data_dir, seed=7, min_words=300):
    rng = random.Random(seed)
    items = []
    for t in tasks:
        rows = [json.loads(l) for l in open(os.path.join(data_dir, f"{t}.jsonl"), encoding="utf-8")]
        rows.sort(key=lambda r: r["_id"])
        rng.shuffle(rows)
        kept = 0
        for r in rows:
            if len(r["context"].split()) < min_words:
                continue
            items.append({"task": t, "id": r["_id"], "context": r["context"],
                          "question": r["input"], "answers": r["answers"]})
            kept += 1
            if kept >= n_per_task:
                break
    return items

def build_prompt(tok, item, max_ctx_tokens):
    ctx_ids = tok(item["context"], add_special_tokens=False).input_ids[:max_ctx_tokens]
    ctx = tok.decode(ctx_ids)
    user = (f"Read the following text and answer the question.\n\n{ctx}\n\n"
            f"Question: {item['question']}\nAnswer:")
    text = tok.apply_chat_template([{"role": "user", "content": user}],
                                   tokenize=False, add_generation_prompt=True)
    return tok(text, return_tensors="pt", add_special_tokens=False).input_ids, text

def make_options(tok, items, i, k=4, max_opt_tokens=8, rng=None):
    """Gold answer + (k-1) distractors drawn from other items' gold answers."""
    rng = rng or random.Random(1234 + i)
    gold = items[i]["answers"][0].strip()
    pool = []
    for j, it in enumerate(items):
        if j == i:
            continue
        a = it["answers"][0].strip()
        if a and a.lower() != gold.lower() and a.lower() not in [p.lower() for p in pool]:
            pool.append(a)
    rng.shuffle(pool)
    opts = [gold] + pool[:k - 1]
    ids = []
    for o in opts:
        t = tok(" " + o, add_special_tokens=False).input_ids[:max_opt_tokens]
        if len(t) < 1:
            t = tok(" unknown", add_special_tokens=False).input_ids
        ids.append(t)
    return opts, ids

# ---------------------------------------------------------------- policies
def position_scores(attn):
    """attn: [layers, H, L, L] -> dict of per-position score vectors (mean over layers)."""
    A = attn.clamp(min=0).mean(dim=0)                 # [H, L, L]
    L = A.shape[-1]
    W = min(32, L)
    recv_all = A.sum(dim=1).sum(dim=0)                # received mass from all queries
    recv_obs = A[:, L - W:, :].sum(dim=1).sum(dim=0)  # observation-window mass (SnapKV)
    recv_last = A[:, -1, :].sum(dim=0)                # current-step mass (QUEST)
    pos = torch.arange(L, dtype=torch.float32)
    return {"h2o": recv_all, "snapkv": recv_obs, "quest": recv_last,
            "lru": pos.clone(), "recv_all": recv_all, "recv_obs": recv_obs}

def protected_indices(L, C, rho, min_side=0):
    k = int(math.ceil(rho * C)) if rho > 0 else 0
    if rho > 0:
        k = max(k, min_side)
    k = min(k, C // 2)
    return list(range(0, k)), list(range(L - k, L))

def retained_set(policy, L, C, rho, scores, seed=0, min_side=0):
    pre, suf = protected_indices(L, C, rho, min_side)
    keep = set(pre) | set(suf)
    if policy == "slw":                      # StreamingLLM: fixed 4 sinks + recency
        n_sink = min(4, C)
        keep = set(range(n_sink))
    budget = C - len(keep)
    if budget <= 0:
        return torch.tensor(sorted(keep)[:C], dtype=torch.long)
    cand = [i for i in range(L) if i not in keep]
    if policy == "lru" or (policy == "slw" and budget > 0):
        order = sorted(cand, reverse=True)
    elif policy in ("h2o", "snapkv", "quest", "oracle"):
        s = scores[policy]
        order = sorted(cand, key=lambda i: (-float(s[i]), i))
    elif policy == "random":
        rng = random.Random(seed * 100003 + L * 7919 + C * 31 + int(rho * 1000))
        order = cand[:]; rng.shuffle(order)
    else:
        raise ValueError(policy)
    keep |= set(order[:budget])
    return torch.tensor(sorted(keep)[:C], dtype=torch.long)

def slice_cache(cache, idx):
    return DynamicCache([(l.keys[:, :, idx, :].contiguous(),
                          l.values[:, :, idx, :].contiguous()) for l in cache.layers])

def clone_cache(cache, idx=None):
    """Fresh copy (optionally sliced). Required because DynamicCache is mutated
    in place by every forward pass, which silently contaminated later options."""
    if idx is None:
        return DynamicCache([(l.keys.clone(), l.values.clone()) for l in cache.layers])
    return slice_cache(cache, idx)

# ---------------------------------------------------------------- scoring
@torch.no_grad()
def prefill(model, ids, want_attn=True):
    out = model(ids, use_cache=True, output_attentions=want_attn)
    attn = torch.stack(out.attentions, 0)[:, 0] if want_attn else None   # [layers, H, L, L]
    return out.cache, attn, out.logits[0, -1].float()

@torch.no_grad()
def option_logprobs(model, cache, pos0, first_logits, opt_ids, idx=None):
    """Total log p(opt | prompt). opt_ids: list of token-id lists.

    `idx` selects which cached positions survive (None = no eviction). The cache is
    cloned per option because DynamicCache grows in place during a forward.
    Cached entries are positionally faithful: keys keep the rotary phase of their
    original absolute positions, and queries keep absolute position ids.
    """
    res, attns = [], []
    for ids in opt_ids:
        n = len(ids)
        if n == 1:
            lp1 = float(torch.log_softmax(first_logits, -1)[ids[0]])
            res.append(lp1); attns.append(None); continue
        t = torch.tensor([ids], dtype=torch.long)
        c = clone_cache(cache, idx)
        out = model(input_ids=t, cache=c,
                    position_ids=torch.arange(pos0, pos0 + n).unsqueeze(0),
                    output_attentions=True)
        lg = out.logits[0].float()
        lp1 = float(torch.log_softmax(first_logits, -1)[ids[0]])
        rest = torch.log_softmax(lg[:-1], -1).gather(1, t[0, 1:, None]).squeeze(1)
        res.append(lp1 + float(rest.sum()))
        attns.append(torch.stack(out.attentions, 0)[:, 0])   # [layers, H, n, C+n]
    return res, attns

@torch.no_grad()
def dense_answer_attention(model, cache, pos0, opt_ids):
    """Attention of the gold-answer queries over the FULL prompt: mass vector [L]."""
    ids = opt_ids[0]
    n = len(ids)
    if n == 1:
        return None
    t = torch.tensor([ids], dtype=torch.long)
    out = model(input_ids=t, cache=clone_cache(cache),
                position_ids=torch.arange(pos0, pos0 + n).unsqueeze(0),
                output_attentions=True)
    A = torch.stack(out.attentions, 0)[:, 0]        # [layers, H, n, L+n]
    mass = A.clamp(min=0).sum(dim=(0, 1, 2))         # [L+n]
    return mass[:pos0].cpu()
