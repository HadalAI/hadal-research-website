"""MC validation: does 4-way accuracy agree with the continuous log-prob readout?"""
import json, math, sys
from collections import defaultdict

def load(p):
    return [json.loads(l) for l in open(p)]

def main(mc_path, nll_path):
    rows = load(mc_path)
    cell = defaultdict(dict)
    for r in rows:
        if r["policy"] == "dense":
            continue
        lp = r["logprobs"]
        acc = 1.0 if (len(lp) > 1 and lp[0] == max(lp)) else 0.0
        # mean gold log-prob per token, comparable to the nll arm
        cell[(r["C"], r["rho"], r["policy"])][r["item_key"]] = (
            acc, lp[0] / max(1, r.get("n_ans_tokens") or 4), len(lp))
    print(f"MC arm: {len(rows)} rows, {len(cell)} cells")
    print("\n| C | rho | policy | n | accuracy | mean gold LP |")
    print("|---|---|---|---|---|---|")
    pairs = []
    for k in sorted(cell):
        d = cell[k]
        a = sum(v[0] for v in d.values()) / len(d)
        l = sum(v[1] for v in d.values()) / len(d)
        pairs.append((a, l))
        print(f"| {k[0]} | {k[1]} | {k[2]} | {len(d)} | {a:.3f} | {l:.3f} |")

    # rank correlation between accuracy and gold LP across cells
    def spear(xs, ys):
        def rank(v):
            o = sorted(range(len(v)), key=lambda i: v[i])
            r = [0] * len(v)
            for pos, i in enumerate(o):
                r[i] = pos
            return r
        rx, ry = rank(xs), rank(ys)
        mx, my = sum(rx) / len(rx), sum(ry) / len(ry)
        num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
        den = math.sqrt(sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry))
        return num / den if den else float("nan")

    xs = [p[0] for p in pairs]; ys = [p[1] for p in pairs]
    if len(pairs) > 3:
        sp = spear(xs, ys)
        # Pearson too
        mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
        num = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
        den = math.sqrt(sum((a - mx) ** 2 for a in xs) * sum((b - my) ** 2 for b in ys))
        print(f"\nSpearman(accuracy, mean gold LP) over cells = {sp:.3f}  (n={len(pairs)} cells)")
        print(f"Pearson = {num/den if den else float('nan'):.3f}")

    # absolute accuracy levels: what is chance and what is the dense accuracy?
    d = [r for r in rows if r["policy"] == "dense"]
    if d:
        acc = sum(1.0 if r["logprobs"][0] == max(r["logprobs"]) else 0.0 for r in d) / len(d)
        print(f"\ndense 4-way accuracy = {acc:.3f} (n={len(d)}); chance = 0.25")

    # correlation restricted to cells present in both arms (same items)
    if nll_path:
        nrows = load(nll_path)
        ncell = defaultdict(dict)
        for r in nrows:
            if r["policy"] != "dense":
                ncell[(r["C"], r["rho"], r["policy"])][r["item_key"]] = \
                    r["logprobs"][0] / max(1, r.get("n_ans_tokens") or 4)
        both = []
        for k, d_ in cell.items():
            if k in ncell:
                common = sorted(set(d_) & set(ncell[k]))
                if len(common) >= 2:
                    a = sum(d_[i][0] for i in common) / len(common)
                    l = sum(ncell[k][i] for i in common) / len(common)
                    both.append((a, l, k))
        if len(both) > 3:
            sp = spear([b[0] for b in both], [b[1] for b in both])
            print(f"\nSpearman(acc, NLL-arm LP) on {len(both)} cells over the same items = {sp:.3f}")
            for b in sorted(both, key=lambda x: -x[1])[:6]:
                print(f"   LP={b[1]:.3f} acc={b[0]:.2f} {b[2]}")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
