"""Fidelity checks for the eviction harness. Every check must print PASS."""
import torch, json, random, sys
sys.path.insert(0, ".")
import harness as H

DATA = "/root/.hermes/profiles/sidequests/cache/scratch/lbdata/data"
torch.manual_seed(0)
m, tok = H.load_model()
items = H.load_items(["2wikimqa"], 3, DATA)
it = items[0]
ids, text = H.build_prompt(tok, it, 600)
L = ids.shape[1]
print("prompt tokens", L, "| structural prefix (chat template) tokens:",
      len(tok.apply_chat_template([{"role":"user","content":""}], tokenize=True, add_generation_prompt=True)))
opts, opt_ids = H.make_options(tok, items, 0)
print("options:", opts, [len(o) for o in opt_ids])

cache, attn, first_logits = H.prefill(m, ids)
print("attn shape", tuple(attn.shape), "rowsum", float(attn.sum(-1).mean()))

# reference 1: option logprobs from a from-scratch full forward
def full_forward_lp(opts_ids):
    out = []
    for o in opts_ids:
        full = torch.cat([ids, torch.tensor([o])], 1)
        with torch.no_grad():
            lg = m(full).logits[0].float()
        # token o[j] predicted by logits at position L+j-1
        lp = torch.log_softmax(lg[L-1:L-1+len(o)], -1)
        out.append(float(lp[torch.arange(len(o)), torch.tensor(o)].sum()))
    return out

ref = full_forward_lp(opt_ids)
got, _ = H.option_logprobs(m, cache, L, first_logits, opt_ids)
print("\nCHECK 1  cache-reuse vs from-scratch full forward")
print("  ref  ", [round(x,4) for x in ref])
print("  got  ", [round(x,4) for x in got])
d1 = max(abs(a-b) for a,b in zip(ref,got))
print(f"  max |diff| = {d1:.2e}  ->", "PASS" if d1 < 1e-3 else "FAIL")

# reference 2: sliced cache vs additive 4-D mask over the full cache
C = 48; rho = 0.1
sc = H.position_scores(attn)
idx = H.retained_set("snapkv", L, C, rho, sc, seed=1)
sl = H.slice_cache(cache, idx)
got_slice, _ = H.option_logprobs(m, sl, L, first_logits, opt_ids)

keep = set(idx.tolist())
got_mask = []
for o in opt_ids:
    n = len(o)
    t = torch.tensor([o])
    bias = torch.full((1, 1, n, L + n), float("-inf"))
    for j in range(n):                       # answer row j may read retained prompt + earlier answers
        bias[0, 0, j, sorted(keep)] = 0.0
        bias[0, 0, j, L:L+j+1] = 0.0
    with torch.no_grad():
        out = m(input_ids=t, cache=H.slice_cache(cache, torch.arange(L)),   # full copy
                position_ids=torch.arange(L, L+n).unsqueeze(0), attention_mask=bias)
    lg = out.logits[0].float()
    lp1 = float(torch.log_softmax(first_logits, -1)[o[0]])
    rest = torch.log_softmax(lg[:-1], -1).gather(1, t[0,1:,None]).squeeze(1) if n > 1 else torch.tensor(0.)
    got_mask.append(lp1 + float(rest.sum()))
print("\nCHECK 2  physically sliced cache vs additive 4-D mask (same retained set)")
print("  slice", [round(x,4) for x in got_slice])
print("  mask ", [round(x,4) for x in got_mask])
d2 = max(abs(a-b) for a,b in zip(got_slice,got_mask))
print(f"  max |diff| = {d2:.2e}  ->", "PASS" if d2 < 2e-3 else "FAIL")

# reference 3: attention mass bookkeeping
mass = H.dense_answer_attention(m, cache, L, opt_ids)
print("\nCHECK 3  dense answer-attention mass over prompt")
print("  rows sum to", float(attn.sum(-1).mean()), "| mass total", float(mass.sum()),
      "| top-1 share of position 0:", round(float(mass[0]/mass.sum()), 4))
for C_ in [8, 16, 32, 64]:
    for rho_ in [0.0, 0.1, 0.5]:
        i_ = H.retained_set("snapkv", L, C_, rho_, sc)
        share = float(mass[i_].sum()/mass.sum())
        print(f"  C={C_:3d} rho={rho_:.1f} retained_attn_mass={share:.4f}")
