"""Measure the analytic retained-mass ceiling: how much of the gold answer's prompt
attention can C slots capture, and what does position 0 alone carry?

No eviction forward passes are needed: the dense answer-attention mass vector suffices.
"""
import json, os, sys
import torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness as H

DATA = "/root/.hermes/profiles/sidequests/cache/scratch/lbdata/data"

def main(model, tag, n=6, ctx=1000, tasks="2wikimqa,qasper,multifieldqa_en,hotpotqa"):
    out = f"./results/mass_{tag}.jsonl"
    done = set()
    if os.path.exists(out):
        for l in open(out):
            done.add(json.loads(l)["item_key"])
    items = H.load_items(tasks.split(","), n, DATA, seed=7)
    m, tok = H.load_model(model)
    f = open(out, "a")
    for ii, it in enumerate(items):
        key = f"{it['task']}/{it['id']}"
        if key in done:
            continue
        ids, text = H.build_prompt(tok, it, ctx)
        L = int(ids.shape[1])
        q = text.rfind("Question:")
        pre = tok(text[:q], add_special_tokens=False).input_ids
        qstart = len(pre)
        cache, attn_tuple, fl = H.prefill(m, ids)
        opts, opt_ids = H.make_options(tok, items, ii, k=4, max_opt_tokens=4)
        mass = H.dense_answer_attention(m, cache, L, opt_ids)
        if mass is None:
            acc = torch.zeros(L)
            for a_ in attn_tuple:
                acc += a_.clamp(min=0)[:, -1, :].sum(0)
            mass = acc / len(attn_tuple)
        tot = float(mass.sum())
        srt = torch.sort(mass, descending=True).values
        cum = torch.cumsum(srt, 0) / tot
        rec = {"item_key": key, "task": it["task"], "L": L, "qstart": qstart,
               "mass_pos0": float(mass[0] / tot),
               "mass_first4": float(mass[:4].sum() / tot),
               "mass_first8": float(mass[:8].sum() / tot),
               "mass_question_span": float(mass[qstart:].sum() / tot),
               "mass_last32": float(mass[-32:].sum() / tot),
               "mass_last8": float(mass[-8:].sum() / tot),
               "ceiling": {str(C): float(cum[min(C, L) - 1]) for C in
                           (1, 2, 4, 8, 16, 32, 64, 128, 256, 512) if C <= L}}
        f.write(json.dumps(rec) + "\n"); f.flush()
        print(f"[{ii+1}] {key[:24]} L={L} pos0={rec['mass_pos0']:.3f} "
              f"qspan={rec['mass_question_span']:.3f} ceil8={rec['ceiling'].get('8'):.3f} "
              f"ceil32={rec['ceiling'].get('32'):.3f}", flush=True)
        del attn_tuple, cache
    f.close()

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "Qwen/Qwen2.5-0.5B-Instruct",
         sys.argv[2] if len(sys.argv) > 2 else "q05")
