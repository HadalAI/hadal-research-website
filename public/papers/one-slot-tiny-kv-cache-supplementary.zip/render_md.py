"""Minimal markdown -> styled HTML for print-to-PDF (tables, headings, lists, bold, code)."""
import html, re, sys

def inline(s):
    s = html.escape(s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"(?<![\w*])\*([^*\n]+)\*(?![\w*])", r"<em>\1</em>", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"<a href='\2'>\1</a>", s)
    return s

def render(md):
    out, i, lines = [], 0, md.split("\n")
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("```"):
            i += 1
            buf = []
            while i < len(lines) and not lines[i].startswith("```"):
                buf.append(html.escape(lines[i])); i += 1
            i += 1
            out.append("<pre><code>" + "\n".join(buf) + "</code></pre>")
            continue
        if ln.startswith(">"):
            out.append("<blockquote>")
            while i < len(lines) and lines[i].startswith(">"):
                buf = []
                while i < len(lines) and lines[i].startswith(">"):
                    buf.append(re.sub(r"^>\s?", "", lines[i])); i += 1
                out.append("<p>" + inline(" ".join(buf)) + "</p>")
            out.append("</blockquote>")
            continue
        if ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            body = [r for r in rows if not re.match(r"^[-: ]+$", "".join(r))]
            if not body:
                continue
            out.append("<table><thead><tr>" + "".join(f"<th>{inline(c)}</th>" for c in body[0])
                       + "</tr></thead><tbody>")
            for r in body[1:]:
                out.append("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>")
            out.append("</tbody></table>")
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", ln)
        if m:
            n = len(m.group(1))
            out.append(f"<h{n}>{inline(m.group(2))}</h{n}>")
            i += 1
            continue
        if ln.strip() == "---":
            out.append("<hr/>"); i += 1; continue
        if re.match(r"^\s*[-*]\s+", ln):
            out.append("<ul>")
            while i < len(lines) and re.match(r"^\s*[-*]\s+", lines[i]):
                out.append("<li>" + inline(re.sub(r"^\s*[-*]\s+", "", lines[i])) + "</li>")
                i += 1
            out.append("</ul>")
            continue
        if re.match(r"^\s*\d+\.\s+", ln):
            out.append("<ol>")
            while i < len(lines) and re.match(r"^\s*\d+\.\s+", lines[i]):
                out.append("<li>" + inline(re.sub(r"^\s*\d+\.\s+", "", lines[i])) + "</li>")
                i += 1
            out.append("</ol>")
            continue
        if ln.strip() == "":
            i += 1; continue
        para = [ln]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r"^(#{1,4}\s|\||\s*[-*]\s|\s*\d+\.\s|---)", lines[i]):
            para.append(lines[i]); i += 1
        out.append("<p>" + inline(" ".join(para)) + "</p>")
    return "\n".join(out)

CSS = """
@page { size: A4; margin: 16mm 14mm; }
body { font: 10.2pt/1.45 "DejaVu Serif", Georgia, serif; color: #111; }
h1 { font-size: 19pt; margin: 0 0 6px; line-height:1.2; }
h2 { font-size: 13pt; margin: 20px 0 6px; border-bottom: 1px solid #ddd; padding-bottom: 3px; }
h3 { font-size: 11pt; margin: 14px 0 4px; }
h4 { font-size: 10pt; margin: 10px 0 3px; }
p { margin: 5px 0; text-align: justify; }
table { border-collapse: collapse; margin: 8px 0 12px; font-size: 8.4pt; width: 100%; }
th, td { border: 1px solid #ccc; padding: 3px 5px; vertical-align: top; }
th { background: #f2f2f2; font-weight: bold; }
code { font-family: "DejaVu Sans Mono", monospace; font-size: 8.6pt; background: #f4f4f4; padding: 0 2px; }
ul, ol { margin: 5px 0 5px 18px; }
li { margin: 2px 0; }
hr { border: 0; border-top: 1px solid #ddd; margin: 14px 0; }
a { color: #14419b; text-decoration: none; }
blockquote { margin: 10px 0; padding: 8px 12px; background: #f7f8fa; border-left: 3px solid #2f7ed8; }
blockquote p { margin: 5px 0; }
pre { background: #f6f6f6; border: 1px solid #e2e2e2; padding: 7px 9px; font-size: 8.2pt; line-height: 1.35;
      white-space: pre-wrap; word-break: break-all; }
pre code { background: none; padding: 0; font-size: 8.2pt; }
"""

if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    body = render(open(src, encoding="utf-8").read())
    open(dst, "w", encoding="utf-8").write(
        f"<!doctype html><html><head><meta charset='utf-8'><style>{CSS}</style></head><body>{body}</body></html>")
    print("html ->", dst, len(body))
