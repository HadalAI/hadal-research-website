"""Audit: re-derive every number in PAPER.md's tables from the raw JSONL and compare."""
import json, re, statistics as st
from collections import defaultdict

WS = "/root/.hermes/kanban/workspaces/t_999fe53c"
PAPER = "/root/.hermes/kanban/workspaces/t_fcc6448b/PAPER.md"
CS = [8, 16, 32, 64, 128, 256]
RHOS = [0.0, 0.05, 0.1, 0.2, 0.3, 0.5]
DEP = ("lru", "h2o", "snapkv", "random", "slw")
FAILS = []
CHECKS = [0]


def per_token(r):
    return sum(r["logprobs"]) / r["n_ans_tokens"] / len(r["logprobs"])


def grid(tag):
    g = defaultdict(dict)
    for r in map(json.loads, open(f"{WS}/results/{tag}.jsonl")):
        k = "dense" if r["policy"] == "dense" else (r["C"], r["policy"], round(r["rho"], 3))
        g[r["item_key"]][k] = per_token(r)
    return g


def fullset(g, extra=("oracle",)):
    return sorted(k for k, v in g.items() if all((C, p, r) in v for C in CS for p in DEP + extra for r in RHOS))


def cm(g, full, C, p, r):
    return st.mean([g[i][(C, p, r)] for i in full])


def tables():
    txt = open(PAPER).read().split("\n")
    out, cur, cap = {}, None, ""
    for ln in txt:
        if ln.startswith("@@TAB"):
            cap = ln
            cur = None
        elif ln.startswith("|") and cap:
            if cur is None:
                cur = []
                out[cap] = cur
            cur.append([c.strip() for c in ln.strip().strip("|").split("|")])
        elif not ln.startswith("|"):
            if ln.strip() == "":
                continue
            cap_prev, cap = cap, ""
    return out


def num(s):
    s = s.replace("−", "-").replace("**", "").replace("×", "").replace(",", "")
    m = re.search(r"-?\d+\.?\d*", s)
    return float(m.group(0)) if m else None


def check(label, got, want, tol=0.006):
    CHECKS[0] += 1
    ok = got is not None and abs(got - want) <= tol
    if not ok:
        FAILS.append(f"{label}: paper={got} computed={want:.4f}")
    return ok


T = tables()
print("tables found:", len(T))

q, s = grid("main_q05"), grid("main_smol")
qf, sf = fullset(q), fullset(s)

# Table 1 / Table 7: gains
for cap, g, full, name in [(c, q, qf, "T1") for c in T if "Protection gain at the best tested fraction" in c and "Qwen" in c] + \
                          [(c, s, sf, "T7") for c in T if "SmolLM2-360M-Instruct" in c]:
    rows = T[cap][2:]
    for row in rows:
        C = int(row[0])
        for j, p in enumerate(("lru", "random", "h2o", "snapkv")):
            best = max(cm(g, full, C, p, r) - cm(g, full, C, p, 0.0) for r in RHOS[1:])
            check(f"{name} gain C={C} {p}", num(row[1 + j]), best)

# Table 2: spread
cap = [c for c in T if "Spread (max" in c][0]
for row in T[cap][2:]:
    C = int(row[0])
    for tag, g in (("q", q), ("s", s)):
        full = qf if tag == "q" else sf
        s0 = max(cm(g, full, C, p, 0.0) for p in DEP) - min(cm(g, full, C, p, 0.0) for p in DEP)
        s5 = max(cm(g, full, C, p, 0.05) for p in DEP) - min(cm(g, full, C, p, 0.05) for p in DEP)
        off = 0 if tag == "q" else 3
        check(f"T2 spread0 {tag} C={C}", num(row[1 + off]), s0, 0.001)
        check(f"T2 spread05 {tag} C={C}", num(row[2 + off]), s5, 0.001)
        check(f"T2 comp {tag} C={C}", num(row[3 + off]), s0 / s5, 0.06)

# Table 3: slots
cap = [c for c in T if "Slots reserved per side" in c][0]
for row in T[cap][2:]:
    C = int(row[0])
    for j, r in enumerate((0.05, 0.1, 0.2, 0.3, 0.5)):
        import math
        check(f"T3 slots C={C} rho={r}", num(row[1 + j]), math.ceil(r * C), 0.001)

# Table 4: mass
m = [json.loads(l) for l in open(f"{WS}/results/mass_q05.jsonl")]
cap = [c for c in T if "Distribution over the 24 Qwen items" in c][0]
keys = ["mass_pos0", "mass_first4", "mass_first8", "mass_question_span", "mass_last32", "mass_last8"]
for row, k in zip(T[cap][2:], keys):
    v = [x[k] for x in m]
    check(f"T4 med {k}", num(row[1]), st.median(v), 0.001)
    check(f"T4 mean {k}", num(row[2]), st.mean(v), 0.001)
    check(f"T4 min {k}", num(row[3]), min(v), 0.001)
    check(f"T4 max {k}", num(row[4]), max(v), 0.001)

# Table 5: headroom
cap = [c for c in T if "Headroom at fixed capacity" in c][0]
for row in T[cap][2:]:
    C = int(row[0])
    oracle = cm(q, qf, C, "oracle", 0.05)
    bestv = max(cm(q, qf, C, p, r) for p in DEP for r in RHOS)
    floor = cm(q, qf, C, "lru", 0.0)
    bs = max(cm(s, sf, C, p, r) for p in DEP for r in RHOS)
    check(f"T5 oracle C={C}", num(row[1]), oracle, 0.001)
    check(f"T5 best C={C}", num(row[2]), bestv, 0.001)
    check(f"T5 gap C={C}", num(row[3]), oracle - bestv, 0.001)
    check(f"T5 recovery C={C}", num(row[4]), (bestv - floor) / (oracle - floor), 0.002)
    check(f"T5 smol C={C}", num(row[5]), cm(s, sf, C, "oracle", 0.05) - bs, 0.001)

# Table 6: ceiling + best deployed
cap = [c for c in T if "achievable-mass ceiling" in c][0]
row_ceil, row_best, row_pct = T[cap][2], T[cap][3], T[cap][4]
ceils = {C: st.mean([x["ceiling"][str(C)] for x in m]) for C in (8, 16, 32, 64, 128, 256)}
for j, C in enumerate([1, 2, 4, 8, 16, 32, 64, 128, 256, 512]):
    ce = st.mean([x["ceiling"][str(C)] for x in m])
    check(f"T6 ceiling C={C}", num(row_ceil[1 + j]), ce, 0.001)
for j, C in enumerate([8, 16, 32, 64, 128, 256]):
    bestm = max(st.mean([r["mass_retained"] for r in map(json.loads, open(f"{WS}/results/main_q05.jsonl"))
                         if r["policy"] == p and r["C"] == C and abs(r["rho"] - rho) < 1e-9 and r["item_key"] in set(qf)])
                for p in DEP for rho in RHOS)
    check(f"T6 best C={C}", num(row_best[4 + j]), bestm, 0.002)
    check(f"T6 pct C={C}", num(row_pct[4 + j]) / 100, bestm / ceils[C], 0.002)

# Appendix A1
cap = [c for c in T if "Mean per-token log-probability" in c][0]
for row in T[cap][2:]:
    C = int(row[0].split(",")[0])
    check(f"A1 oracle C={C}", num(row[7]), cm(q, qf, C, "oracle", 0.05), 0.001)
    for j, r in enumerate(RHOS):
        check(f"A1 lru C={C} rho={r}", num(row[1 + j]), cm(q, qf, C, "lru", r), 0.001)

# dense references quoted in prose
check("dense24", 8.462, abs(st.mean([v["dense"] for v in q.values()])), 0.001)
check("dense23", 8.082, abs(st.mean([q[i]["dense"] for i in qf])), 0.001)
check("dense_smol", 7.519, abs(st.mean([v["dense"] for v in s.values()])), 0.001)

print("\nchecks:", CHECKS[0], "\nFAILS:", len(FAILS))
for f in FAILS:
    print("  ", f)
