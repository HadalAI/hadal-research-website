"""Extra checks: (a) policy spread before/after protection, (b) the one-slot claim at C=8/16,
(c) recovery relative to the oracle ceiling, (d) per-item worst/best."""
import json, math, sys
from collections import defaultdict

p = sys.argv[1] if len(sys.argv) > 1 else "results/main_q05.jsonl"
rows = [json.loads(l) for l in open(p)]
def lp(r):
    n = r.get("n_ans_tokens") or 4
    return r["logprobs"][0] / max(1, n)
dense = {r["item_key"]: lp(r) for r in rows if r["policy"] == "dense"}
cell = defaultdict(dict)
for r in rows:
    if r["policy"] != "dense":
        cell[(r["C"], r["rho"], r["policy"])][r["item_key"]] = lp(r)
budgets = sorted({k[0] for k in cell})
pols = sorted({k[2] for k in cell})
real = [q for q in pols if q != "oracle"]

def M(c, rho, pol):
    d = cell.get((c, rho, pol), {})
    return sum(d.values()) / len(d) if d else float("nan")

print("=== policy spread (max-min over real policies) before and after protection ===")
print("C    rho=0     best-rho(0.05/0.1)   compression factor   oracle spread")
for c in budgets:
    s0 = max(M(c, 0.0, q) for q in real) - min(M(c, 0.0, q) for q in real)
    best_rho = min((0.05, 0.1), key=lambda r: -(max(M(c, r, q) for q in real) - min(M(c, r, q) for q in real)))
    sp = max(M(c, best_rho, q) for q in real) - min(M(c, best_rho, q) for q in real)
    orc = M(c, 0.0, "oracle")
    best = max(M(c, r, q) for q in real for r in (0.0, 0.05, 0.1, 0.2, 0.3, 0.5))
    print(f"{c:4d} {s0:8.3f} {sp:18.3f} (rho={best_rho}) {s0/max(sp,1e-9):14.1f}x  "
          f"oracle-best={orc-best:+.3f}")

print("\n=== best real policy vs FLOOR (LRU,rho=0) and CEILING (oracle at same C) ===")
print("C    floor    ceiling(oracle)  best-real  recovery  gap-to-ceiling")
for c in budgets:
    floor = M(c, 0.0, "lru"); ceil_ = M(c, 0.0, "oracle")
    br = max(((M(c, r, q), q, r) for q in real for r in (0.0, 0.05, 0.1, 0.2, 0.3, 0.5)))
    rec = (br[0] - floor) / (ceil_ - floor) if ceil_ != floor else float("nan")
    print(f"{c:4d} {floor:8.3f} {ceil_:14.3f} {br[0]:10.3f} ({br[1][:6]},r={br[2]:.2f}) "
          f"{rec:8.3f} {br[0]-ceil_:+.3f}")

print("\n=== retained-mass ceiling vs realised mass (best real policy) ===")
print("C    ceiling  achieved  fraction-of-ceiling")
massm = defaultdict(dict)
for r in rows:
    if r["policy"] != "dense":
        massm[(r["C"], r["rho"], r["policy"])][r["item_key"]] = r["mass_retained"]
for c in budgets:
    ceil_ = sum(massm[(c, 0.0, "oracle")].values()) / len(massm[(c, 0.0, "oracle")])
    best = max(((sum(massm[(c, r, q)].values()) / len(massm[(c, r, q)]), q, r)
                for q in real for r in (0.0, 0.05, 0.1, 0.2, 0.3, 0.5) if (c, r, q) in massm))
    print(f"{c:4d} {ceil_:8.3f} {best[0]:8.3f} ({best[1]},r={best[2]:.2f}) {best[0]/ceil_:8.3f}")
