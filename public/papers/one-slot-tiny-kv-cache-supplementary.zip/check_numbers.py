#!/usr/bin/env python3
"""Cross-check every numeric token in the LaTeX table bodies against PAPER.md."""
import re, collections, sys

MD = "/root/.hermes/kanban/attachments/t_f6448b/PAPER.md"
MD = "/root/.hermes/kanban/attachments/t_fcc6448b/PAPER.md"
NUM = re.compile(r"[-+]?\d+(?:\.\d+)?")

def md_tables(path):
    tables, cur = [], None
    for ln in open(path).read().splitlines():
        s = ln.strip()
        if s.startswith("|"):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if set("".join(cells)) <= set("-: "):
                continue
            cur = cur or []
            cur.append(cells)
        elif cur:
            tables.append(cur); cur = None
    if cur:
        tables.append(cur)
    return tables

def norm_md(cell):
    c = cell.replace("**", "").replace("\u2212", "-").replace("\u00d7", "x")
    return [round(float(t), 3) for t in NUM.findall(c)]

def tex_body(path):
    s = open(path).read()
    s = re.sub(r"(?<!\\)%.*", "", s)              # strip real comments only
    body = s.split("\\midrule", 1)[1].split("\\bottomrule", 1)[0]
    body = body.replace("\u2212", "-")
    rows = [r for r in body.split("\\\\") if r.strip()]
    out = []
    for r in rows:
        r = re.sub(r"\\([a-zA-Z]+)\*?", "", r)          # drop command names, keep arguments
        r = re.sub(r"(\d)--(\d)", r"\1 \2", r)             # en-dash ranges
        out += [round(float(t), 3) for t in NUM.findall(r)]
    return out

files = ["t1", "t2", "t3", "t4", "t5", "t6", "t7", "tA1body"]  # tA1body: shared tabular body of Table 8
md = md_tables(MD)
print(f"parsed {len(md)} markdown tables, checking {len(files)} LaTeX tables")
bad = 0
for name, table in zip(files, md):
    md_nums = []
    for row in table[1:]:                     # skip header row
        for c in row:
            md_nums += norm_md(c)
    tx = tex_body(f"tabs/{name}.tex")
    a, b = collections.Counter(md_nums), collections.Counter(tx)
    missing, extra = a - b, b - a
    status = "OK" if not missing and not extra else "MISMATCH"
    bad += status != "OK"
    print(f"{name:4s} {status:9s} md={sum(a.values()):3d} tex={sum(b.values()):3d} "
          f"missing={dict(list(missing.items())[:5])} extra={dict(list(extra.items())[:5])}")
print("\nRESULT:", "all table bodies match PAPER.md" if bad == 0 else f"{bad} tables differ")
sys.exit(0 if bad == 0 else 1)
