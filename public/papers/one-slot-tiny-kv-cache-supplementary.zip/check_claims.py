#!/usr/bin/env python3
"""Check that the paper's headline numbers survive into every built PDF."""
import subprocess, sys

CLAIMS = {
    "+5.78 (LRU gain at C=8)": "5.78",
    "+2.37 (LRU gain at C=256)": "2.37",
    "13.9x compression at C=8": "13.9",
    "8.2x at C=256": "8.2",
    "1.081 nats headroom at C=8": "1.081",
    "0.187 nats at C=256": "0.187",
    "position 0 mass 0.370": "0.370",
    "37% of attention mass": "37%",
    "76% of damage recovered": "76%",
    "SmolLM2 +7.35": "7.35",
    "replication 2.05": "2.05",
    "oracle gap -0.025": "0.025",
    "R2 = 0.38": "0.38",
    "Spearman 0.832": "0.832",
    "dense -8.462": "8.462",
    "exactness 2.5e-5": "2.5",
}
ok = True
for v in ("arxiv", "tmlr", "icml", "mlsys"):
    txt = subprocess.run(["pdftotext", f"build/{v}/main_{v}.pdf", "-"],
                         capture_output=True, text=True).stdout
    flat = "".join(txt.split())
    miss = [k for k, tok in CLAIMS.items() if "".join(tok.split()) not in flat]
    print(f"{v:6s} {'all headline tokens present' if not miss else 'MISSING: ' + ', '.join(miss)}")
    ok &= not miss
sys.exit(0 if ok else 1)
