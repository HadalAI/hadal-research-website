"""Produce every table and statistic used in the notes, directly from the raw JSONL.

Writes <out>.md and <out>.json. No number in the notes is typed by hand.
"""
import json, math, os, random, sys
from collections import defaultdict

def load(path):
    return [json.loads(l) for l in open(path)]

def lp(r):
    n = r.get("n_ans_tokens") or 4
    return r["logprobs"][0] / max(1, n)

def paired_boot(diffs, n=10000, rng=None):
    rng = rng or random.Random(12345)
    N = len(diffs)
    if N == 0:
        return (float("nan"),) * 3 + (float("nan"),)
    ms = []
    for _ in range(n):
        ms.append(sum(diffs[rng.randrange(N)] for _ in range(N)) / N)
    ms.sort()
    return (sum(diffs) / N, ms[int(0.025 * n)], ms[int(0.975 * n) - 1],
            sum(1 for x in ms if x <= 0) / n)

def t_p(diffs):
    N = len(diffs)
    if N < 3:
        return float("nan")
    m = sum(diffs) / N
    var = sum((d - m) ** 2 for d in diffs) / (N - 1)
    if var <= 0:
        return 0.0 if m else 1.0
    t = m / math.sqrt(var / N)
    # Student-t two-sided p, df=N-1, via incomplete beta
    df = N - 1
    x = df / (df + t * t)
    def betacf(a, b, x, itmax=200):
        qab, qap, qam = a + b, a + 1.0, a - 1.0
        c, d = 1.0, 1.0 - qab * x / qap
        d = 1e-30 if abs(d) < 1e-30 else d
        d = 1.0 / d
        h = d
        for m_ in range(1, itmax + 1):
            m2 = 2 * m_
            aa = m_ * (b - m_) * x / ((qam + m2) * (a + m2))
            d = 1.0 + aa * d; d = 1e-30 if abs(d) < 1e-30 else d
            c = 1.0 + aa / c; c = 1e-30 if abs(c) < 1e-30 else c
            d = 1.0 / d; h *= d * c
            aa = -(a + m_) * (qab + m_) * x / ((a + m2) * (qap + m2))
            d = 1.0 + aa * d; d = 1e-30 if abs(d) < 1e-30 else d
            c = 1.0 + aa / c; c = 1e-30 if abs(c) < 1e-30 else c
            d = 1.0 / d; de = d * c; h *= de
            if abs(de - 1.0) < 1e-12:
                break
        return h
    a, b = df / 2.0, 0.5
    lbeta = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
    if x < (a + 1) / (a + b + 2):
        ib = math.exp(a * math.log(x) + b * math.log(1 - x) - lbeta) * betacf(a, b, x) / a
    else:
        ib = 1 - math.exp(b * math.log(1 - x) + a * math.log(x) - lbeta) * betacf(b, a, 1 - x) / b
    return max(0.0, min(1.0, ib))

def main(path, label, out_md):
    rows = load(path)
    items = sorted({r["item_key"] for r in rows if r["policy"] == "dense"})
    dense = {r["item_key"]: lp(r) for r in rows if r["policy"] == "dense"}
    budgets = sorted({r["C"] for r in rows if r["C"] > 0})
    rhos = sorted({r["rho"] for r in rows if r["C"] > 0})
    pols = sorted({r["policy"] for r in rows if r["policy"] != "dense"})
    cell, mass = defaultdict(dict), defaultdict(dict)
    tasks = {}
    for r in rows:
        tasks[r["item_key"]] = r["task"]
        if r["policy"] == "dense":
            continue
        cell[(r["C"], r["rho"], r["policy"])][r["item_key"]] = lp(r)
        mass[(r["C"], r["rho"], r["policy"])][r["item_key"]] = r["mass_retained"]

    def M(c, rho, p, src=cell):
        d = src.get((c, rho, p), {})
        return sum(d.values()) / len(d) if d else float("nan")

    L = []; w = L.append
    w(f"# Results — {label}")
    w(f"\nrows={len(rows)} items={len(items)} C={budgets} rho={rhos} policies={pols}")
    w(f"\ndense mean per-token logprob = {sum(dense.values())/len(dense):.4f} (n={len(dense)})")

    w("\n## T1 — Mean per-token logprob of the gold answer (higher is better)\n")
    w("| C | rho | " + " | ".join(pols) + " | dense |")
    w("|---|---|" + "---|" * (len(pols) + 1))
    dc = sum(dense.values()) / len(dense)
    for c in budgets:
        for rho in rhos:
            w(f"| {c} | {rho} | " + " | ".join(f"{M(c,rho,p):.3f}" for p in pols) + f" | {dc:.3f} |")

    w("\n## T2 — Protection gain at fixed (C, policy): LP(rho) - LP(rho=0), paired over items\n")
    w("| C | policy | rho | slots/side | gain | 95% CI | P(boot<=0) | p(t) | n |")
    w("|---|---|---|---|---|---|---|---|---|")
    gains = {}
    for c in budgets:
        for p in pols:
            for rho in rhos:
                if rho == 0:
                    continue
                a, b = cell.get((c, rho, p), {}), cell.get((c, 0.0, p), {})
                common = sorted(set(a) & set(b))
                if not common:
                    continue
                d = [a[i] - b[i] for i in common]
                mm, lo, hi, pw = paired_boot(d)
                gains[(c, rho, p)] = (mm, lo, hi, pw, len(d))
                k = min(int(math.ceil(rho * c)), c // 2)
                w(f"| {c} | {p} | {rho} | {k} | {mm:+.3f} | [{lo:+.3f},{hi:+.3f}] | "
                  f"{pw:.4f} | {t_p(d):.2g} | {len(d)} |")

    w("\n## T3 — Optimal protection fraction and the absolute slot count it implies\n")
    w("| C | policy | rho* | slots/side k* | gain at rho* | 95% CI |")
    w("|---|---|---|---|---|---|")
    kmin = {}
    for c in budgets:
        for p in pols:
            cand = {rho: gains[(c, rho, p)] for rho in rhos if (c, rho, p) in gains}
            if not cand:
                continue
            best = max(cand, key=lambda r: cand[r][0])
            k = min(int(math.ceil(best * c)), c // 2)
            kmin[(c, p)] = (best, k, cand[best][0])
            g = cand[best]
            w(f"| {c} | {p} | {best:.2f} | {k} | {g[0]:+.3f} | [{g[1]:+.3f},{g[2]:+.3f}] |")

    w("\n## T4 — Does protection still pay? Max gain over rho, per (C, policy)\n")
    w("| C | " + " | ".join(pols) + " |")
    w("|---|" + "---|" * len(pols))
    for c in budgets:
        vals = []
        for p in pols:
            g = max((gains[(c, r, p)][0] for r in rhos if (c, r, p) in gains), default=float("nan"))
            vals.append(f"{g:+.3f}")
        w(f"| {c} | " + " | ".join(vals) + " |")

    w("\n## T5 — Mechanism: per-item dLP vs retained attention mass\n")
    xs, ys = [], []
    for k, d in cell.items():
        if k[0] <= 0:
            continue
        for it, v in d.items():
            m_ = mass[k][it]
            if it in dense and m_ is not None:
                xs.append(m_); ys.append(v - dense[it])
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxy = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
    sxx = sum((a - mx) ** 2 for a in xs); syy = sum((b - my) ** 2 for b in ys)
    beta = sxy / sxx if sxx else float("nan"); r2 = sxy ** 2 / (sxx * syy) if sxx and syy else float("nan")
    lz = [math.log(max(1e-6, 1 - x)) for x in xs]
    mz = sum(lz) / n
    sl = sum((a - mz) * (b - my) for a, b in zip(lz, ys)) / sum((a - mz) ** 2 for a in lz)
    r2l = (sum((a - mz) * (b - my) for a, b in zip(lz, ys)) ** 2) / (
        sum((a - mz) ** 2 for a in lz) * sum((b - my) ** 2 for b in ys))
    w(f"n={n}. Linear: dLP = {my - beta*mx:+.3f} {beta:+.3f}*mass, R^2={r2:.4f}")
    w(f"Log-linear: dLP ~ {sl:+.3f}*log(1-mass) + c, R^2={r2l:.4f}")
    w("\n| retained mass | n | mean dLP | 95% CI |")
    w("|---|---|---|---|")
    bins = defaultdict(list)
    for a, b in zip(xs, ys):
        bins[round(min(a, 1.0) * 10) / 10].append(b)
    for b in sorted(bins):
        v = bins[b]; mm, lo, hi, _ = paired_boot(v, n=2000)
        w(f"| {b:.1f} | {len(v)} | {mm:+.4f} | [{lo:+.3f},{hi:+.3f}] |")

    w("\n## T6 — Oracle headroom (future-query selection)\n")
    w("| C | dense | oracle | best real policy | best-policy gap | oracle gap to best-policy |")
    w("|---|---|---|---|---|---|")
    for c in budgets:
        orc = M(c, 0.0, "oracle")
        real = max(((M(c, r, p), p, r) for p in pols if p != "oracle" for r in rhos),
                   default=(float("nan"), "", 0))
        w(f"| {c} | {M(c,0.0,'lru'):.3f}* | {orc:.3f} | {real[0]:.3f} ({real[1]}, rho={real[2]}) | "
          f"{real[0]-orc:+.3f} | {orc-real[0]:+.3f} |")
    w("\n\\* dense is listed per item in T1; the column here shows LRU at rho=0 for reference.")

    w("\n## T7 — Structural span (tokens from 'Question:' to prompt end), over items\n")
    sp = [r["struct_span"] for r in rows if r["policy"] == "dense" and r["struct_span"] > 0]
    sp.sort()
    if sp:
        w(f"n={len(sp)} min={sp[0]} p25={sp[len(sp)//4]} median={sp[len(sp)//2]} "
          f"mean={sum(sp)/len(sp):.1f} max={sp[-1]}")
        w(f"prefix_exact flags: {sorted({r['prefix_exact'] for r in rows if r['policy']=='dense'})}")

    w("\n## T8 — Retained attention mass by cell\n")
    w("| C | rho | " + " | ".join(pols) + " |")
    w("|---|---|" + "---|" * len(pols))
    for c in budgets:
        for rho in rhos:
            w(f"| {c} | {rho} | " + " | ".join(f"{M(c,rho,p,mass):.3f}" for p in pols) + " |")

    w("\n## T9 — Per-task mean LP at rho=0.05 and rho=0.5, LRU\n")
    w("| C | task | n | rho=0 | rho=0.05 | rho=0.5 | dense |")
    w("|---|---|---|---|---|---|---|")
    byt = defaultdict(dict)
    for (c, rho, p), d in cell.items():
        if p != "lru":
            continue
        for it, v in d.items():
            byt[(c, tasks[it], rho)][it] = v
    for c in budgets:
        for t in sorted(set(tasks.values())):
            row = []
            ns = 0
            for rho in (0.0, 0.05, 0.5):
                d = byt.get((c, t, rho), {})
                row.append(sum(d.values()) / len(d) if d else float("nan"))
                ns = len(d)
            dd = [dense[i] for i in dense if tasks[i] == t]
            w(f"| {c} | {t} | {ns} | {row[0]:.3f} | {row[1]:.3f} | {row[2]:.3f} | "
              f"{sum(dd)/len(dd):.3f} |")

    open(out_md, "w").write("\n".join(L) + "\n")
    json.dump({"label": label, "n_items": len(items), "dense": dc,
               "gains": {f"{k[0]}|{k[1]}|{k[2]}": v[:4] for k, v in gains.items()},
               "kmin": {f"{k[0]}|{k[1]}": v for k, v in kmin.items()},
               "mech": {"n": n, "beta": beta, "r2": r2, "log_r2": r2l, "slope_log": sl}},
              open(out_md.replace(".md", ".json"), "w"), indent=1)
    print(f"wrote {out_md}  items={len(items)} cells={len(cell)}")

if __name__ == "__main__":
    p = sys.argv[1]
    main(p, sys.argv[2] if len(sys.argv) > 2 else os.path.basename(p),
         sys.argv[3] if len(sys.argv) > 3 else p.replace(".jsonl", "_tables.md"))
