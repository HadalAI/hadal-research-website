#!/usr/bin/env python3
"""Locate the end of the main text in each build and test it against the venue limit.

The main text ends at the first of: a section that must precede the References but
does not count toward the limit (ICML 2027 "AI Use Statement" / "Impact Statement",
MLSys "AI Usage Disclosure", any Acknowledgements), or the References heading. The
position is located in the built PDF, so the number reported here is measured, not
estimated from the source.
"""
import subprocess, re, json, os

LIMITS = {"icml": 8, "mlsys": 10, "colm": 9, "acl": 8, "arxiv": None, "tmlr": None}

FREE_HEADS = ("ACKNOWLEDGEMENTS", "ACKNOWLEDGMENTS", "IMPACTSTATEMENT",
              "AIUSESTATEMENT", "AIUSAGEDISCLOSURE", "AIUSDISCLOSURE")


def npages(pdf):
    out = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout
    return int(re.search(r"Pages:\s+(\d+)", out).group(1))


def ptext(pdf, pg):
    return subprocess.run(["pdftotext", "-layout", "-f", str(pg), "-l", str(pg), pdf, "-"],
                          capture_output=True, text=True).stdout


def is_refs(line):
    for cell in re.split(r"\s{3,}", line):
        c = re.sub(r"^\d+\s*", "", cell.strip())
        c = re.sub(r"\s+", "", c).upper()
        if c.startswith("REFERENCES") and len(c) <= 12:
            return True
    return False


def is_free(line):
    # -layout puts both columns on one line, so test every column cell, not the line
    for cell in re.split(r"\s{2,}", line):
        c = re.sub(r"\s+", "", cell).upper()
        if any(c.startswith(k) for k in FREE_HEADS):
            return True
    return False


rows = {}
for v, limit in LIMITS.items():
    pdf = f"build/{v}/main_{v}.pdf"
    if not os.path.exists(pdf):
        rows[v] = {"pages": None, "references_page": None, "body_pages": None,
                   "limit": limit, "within_limit": None, "skipped": "no build"}
        print(f"{v:6s} skipped (no build/{v}/main_{v}.pdf)")
        continue

    n = npages(pdf)
    refs = free = None          # (page, line index, lines on page, label)
    for pg in range(1, n + 1):
        lines = [l for l in ptext(pdf, pg).splitlines() if l.strip()]
        for i, l in enumerate(lines):
            if refs is None and is_refs(l):
                refs = (pg, i, len(lines), "References")
            if free is None and is_free(l):
                free = (pg, i, len(lines), re.sub(r"\s+", " ", l.strip()))
        if refs is not None:
            break

    if refs and free:
        end = free if (free[0], free[1]) <= (refs[0], refs[1]) else refs
    else:
        end = free or refs

    # line 0 on a page is the running head, not body text
    body_pages = None
    if end:
        body_pages = round(end[0] - 1 + max(0, end[1] - 1) / max(end[2], 1), 2)
    ok = None if limit is None else (body_pages is not None and body_pages <= limit)
    rows[v] = {"pages": n, "references_page": refs[0] if refs else None,
               "body_ends_at": (f"p{end[0]}, line {end[1]}: {end[3]}" if end else None),
               "body_pages": body_pages, "limit": limit, "within_limit": ok}
    print(f"{v:6s} pages={n:3d} body_pages={body_pages} limit={limit} within={ok}"
          f"  [{end[3] if end else 'n/a'} on p{end[0] if end else '-'}]")

json.dump(rows, open("build/page_limits.json", "w"), indent=2)
