import re, subprocess, collections
NUM = re.compile(r"\d+(?:\.\d+)?")
md = open("/root/.hermes/kanban/attachments/t_fcc6448b/PAPER.md").read()
md = re.sub(r"(?m)^\s*\|.*$", "", md)                 # drop tables (checked separately)
md = re.sub(r"arXiv:\d+\.\d+", " ", md)               # drop arXiv ids
md_vals = set(NUM.findall(md))
txt = subprocess.run(["pdftotext", "build/arxiv/main_arxiv.pdf", "-"],
                     capture_output=True, text=True).stdout
flat = "".join(txt.split())
missing = sorted(v for v in md_vals if v not in flat)
print("distinct numeric values in the markdown prose:", len(md_vals))
print("absent from the built PDF:", missing)
