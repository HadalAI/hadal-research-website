"""SVG figures straight from the raw JSONL. No external plotting library."""
import json, math, os, sys
from collections import defaultdict

RES = "./results"
COL = {"lru": "#e0483c", "h2o": "#2f7ed8", "snapkv": "#1f9e63", "random": "#8e6bd8",
       "slw": "#d8931f", "oracle": "#111111", "dense": "#888888"}
POLS = ["lru", "h2o", "snapkv", "random", "slw", "oracle"]
W, H = 980, 340
FONT = "font-family='DejaVu Sans,Helvetica,sans-serif'"

def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def axe(x0, y0, x1, y1):
    return (f"<line x1='{x0}' y1='{y1}' x2='{x1}' y2='{y1}' stroke='#333' stroke-width='1'/>"
            f"<line x1='{x0}' y1='{y0}' x2='{x0}' y2='{y1}' stroke='#333' stroke-width='1'/>")

def txt(x, y, s, size=11, anchor="start", weight="normal", fill="#222"):
    return (f"<text x='{x:.1f}' y='{y:.1f}' {FONT} font-size='{size}' text-anchor='{anchor}' "
            f"font-weight='{weight}' fill='{fill}'>{esc(s)}</text>")

def pl(pts, col, w=2, dash=None):
    if not pts:
        return ""
    d = "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    da = f" stroke-dasharray='{dash}'" if dash else ""
    return f"<path d='{d}' fill='none' stroke='{col}' stroke-width='{w}'{da}/>"

def load(path):
    rows = [json.loads(l) for l in open(path)]
    def lp(r):
        return r["logprobs"][0] / max(1, r.get("n_ans_tokens") or 4)
    dense = {r["item_key"]: lp(r) for r in rows if r["policy"] == "dense"}
    cell, mass = defaultdict(dict), defaultdict(dict)
    for r in rows:
        if r["policy"] != "dense":
            cell[(r["C"], r["rho"], r["policy"])][r["item_key"]] = lp(r)
            mass[(r["C"], r["rho"], r["policy"])][r["item_key"]] = r["mass_retained"]
    return rows, dense, cell, mass

def mean(d):
    return sum(d.values()) / len(d) if d else float("nan")

def fig_rho(cell, dense, out):
    budgets = sorted({k[0] for k in cell}); rhos = sorted({k[1] for k in cell})
    dc = mean(dense)
    allv = [mean(cell[(c, r, p)]) for (c, r, p) in cell] + [dc]
    lo, hi = min(allv) - .3, max(allv) + .3
    cols, rows_ = 3, 2
    pw, ph = W // cols, 250
    s = [f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{ph*rows_+80}' viewBox='0 0 {W} {ph*rows_+80}'>",
         f"<rect width='100%' height='100%' fill='#fff'/>",
         txt(14, 22, "Protection fraction vs quality, per capacity (gold-answer log-prob, higher is better)", 15, weight="bold")]
    lx = 20
    for p in POLS:
        s.append(f"<line x1='{lx}' y1='{42}' x2='{lx+16}' y2='{42}' stroke='{COL[p]}' stroke-width='2.5'"
                 f"{' stroke-dasharray=6,3' if p == 'oracle' else ''}/>")
        s.append(txt(lx + 21, 46, p, 10)); lx += 108
    s.append(f"<line x1='{lx}' y1='{42}' x2='{lx+16}' y2='{42}' stroke='#888' stroke-dasharray='4,3'/>")
    s.append(txt(lx + 21, 46, "dense", 10))
    for i, c in enumerate(budgets):
        gx = (i % cols) * pw + 60
        gy = (i // cols) * ph + 78
        w_, h_ = pw - 90, ph - 90
        s.append(axe(gx, gy, gx + w_, gy + h_))
        for j in range(5):
            v = lo + (hi - lo) * j / 4
            y = gy + h_ - (v - lo) / (hi - lo) * h_
            s.append(f"<line x1='{gx}' y1='{y:.1f}' x2='{gx+w_}' y2='{y:.1f}' stroke='#eee'/>")
            s.append(txt(gx - 4, y + 4, f"{v:.1f}", 9, "end", fill="#666"))
        yv = gy + h_ - (dc - lo) / (hi - lo) * h_
        s.append(f"<line x1='{gx}' y1='{yv:.1f}' x2='{gx+w_}' y2='{yv:.1f}' stroke='#888' "
                 f"stroke-width='1' stroke-dasharray='4,3'/>")
        for p in POLS:
            pts = []
            for r in rhos:
                v = mean(cell.get((c, r, p), {}))
                if not math.isnan(v):
                    pts.append((gx + (r / max(rhos)) * w_, gy + h_ - (v - lo) / (hi - lo) * h_))
            s.append(pl(pts, COL[p], 1.9, "6,3" if p == "oracle" else None))
        s.append(txt(gx + w_ / 2, gy - 8, f"C = {c}", 12, "middle", "bold"))
        s.append(txt(gx + w_ / 2, gy + h_ + 16, "rho (per side)", 10, "middle", fill="#444"))
        for r in (0.0, 0.2, 0.4):
            xx = gx + (r / max(rhos)) * w_
            s.append(txt(xx, gy + h_ + 30, f"{r:.1f}", 9, "middle", fill="#666"))
        if i % cols == 0:
            s.append(f"<text x='{gx-40}' y='{gy+h_/2}' {FONT} font-size='10' fill='#444' "
                     f"transform='rotate(-90 {gx-40} {gy+h_/2})' text-anchor='middle'>mean log-prob</text>")
    s.append("</svg>")
    open(out, "w").write("\n".join(s))

def fig_cap(cell, dense, out):
    budgets = sorted({k[0] for k in cell})
    rhos = sorted({k[1] for k in cell})
    dc = mean(dense)
    allv = [mean(cell[(c, r, p)]) for (c, r, p) in cell] + [dc]
    lo, hi = min(allv) - .3, max(allv) + .3
    gx, gy, w_, h_ = 90, 70, W - 200, 230
    s = [f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{h_+150}' viewBox='0 0 {W} {h_+150}'>",
         f"<rect width='100%' height='100%' fill='#fff'/>",
         txt(14, 24, "Quality vs capacity: protection closes most of the gap at every C", 15, weight="bold"),
         axe(gx, gy, gx + w_, gy + h_)]
    for j in range(5):
        v = lo + (hi - lo) * j / 4
        y = gy + h_ - (v - lo) / (hi - lo) * h_
        s.append(f"<line x1='{gx}' y1='{y:.1f}' x2='{gx+w_}' y2='{y:.1f}' stroke='#eee'/>")
        s.append(txt(gx - 6, y + 4, f"{v:.1f}", 9, "end", fill="#666"))
    xs = {c: gx + i * w_ / (len(budgets) - 1) for i, c in enumerate(budgets)}
    for c in budgets:
        s.append(txt(xs[c], gy + h_ + 18, str(c), 11, "middle"))
        s.append(f"<line x1='{xs[c]}' y1='{gy}' x2='{xs[c]}' y2='{gy+h_}' stroke='#f4f4f4'/>")
    series = [(("lru", 0.0), "LRU, no protection", "#e0483c", "5,3"),
              (("lru", 0.05), "LRU, rho=0.05", "#e0483c", None),
              (("lru", 0.1), "LRU, rho=0.10 (source default)", "#b3291e", None),
              (("random", 0.0), "random, no protection", "#8e6bd8", "5,3"),
              (("random", 0.1), "random, rho=0.10", "#8e6bd8", None),
              (("oracle", 0.0), "oracle (future-query top-C)", "#111111", "2,2")]
    for (p, r), lab, col, dash in series:
        pts = [(xs[c], gy + h_ - (mean(cell[(c, r, p)]) - lo) / (hi - lo) * h_)
               for c in budgets if (c, r, p) in cell]
        s.append(pl(pts, col, 2.4, dash))
    yv = gy + h_ - (dc - lo) / (hi - lo) * h_
    s.append(f"<line x1='{gx}' y1='{yv:.1f}' x2='{gx+w_}' y2='{yv:.1f}' stroke='#888' stroke-dasharray='4,3'/>")
    s.append(txt(gx + w_ - 4, yv - 6, f"dense {dc:.2f}", 10, "end", fill="#666"))
    s.append(txt(gx + w_ / 2, gy + h_ + 40, "cache capacity C (tokens, shared across all layers and KV heads)",
                 11, "middle", fill="#333"))
    lx = 60
    for (p, r), lab, col, dash in series:
        da = " stroke-dasharray='5,3'" if dash else ""
        s.append(f"<line x1='{lx}' y1='{h_+110}' x2='{lx+20}' y2='{h_+110}' stroke='{col}' "
                 f"stroke-width='2.4'{da}/>")
        s.append(txt(lx + 25, h_ + 114, lab, 10)); lx += 30 + 7 * len(lab)
    s.append("</svg>")
    open(out, "w").write("\n".join(s))

def fig_rule(cell, out, spans):
    budgets = sorted({k[0] for k in cell}); rhos = sorted({k[1] for k in cell})
    gx, gy, w_, h_ = 90, 70, W - 200, 220
    s = [f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{h_+150}' viewBox='0 0 {W} {h_+150}'>",
         f"<rect width='100%' height='100%' fill='#fff'/>",
         txt(14, 24, "Optimal reservation in absolute slots: one slot per side suffices at C<=16", 15, weight="bold"),
         axe(gx, gy, gx + w_, gy + h_)]
    maxk = 30
    for j in range(5):
        v = maxk * j / 4
        y = gy + h_ - v / maxk * h_
        s.append(f"<line x1='{gx}' y1='{y:.1f}' x2='{gx+w_}' y2='{y:.1f}' stroke='#eee'/>")
        s.append(txt(gx - 6, y + 4, f"{int(v)}", 9, "end", fill="#666"))
    xs = {c: gx + i * w_ / (len(budgets) - 1) for i, c in enumerate(budgets)}
    for c in budgets:
        s.append(txt(xs[c], gy + h_ + 18, str(c), 11, "middle"))
    if spans:
        lo_s, hi_s = min(spans), max(spans)
        y1 = gy + h_ - min(hi_s, maxk) / maxk * h_
        s.append(f"<rect x='{gx}' y='{y1:.1f}' width='{w_}' height='{h_-(gy+h_-y1):.1f}' "
                 f"fill='#1f9e63' opacity='0.10'/>")
        s.append(txt(gx + 6, y1 - 6, f"measured question span: {lo_s}-{hi_s} tokens", 10, fill="#1f9e63"))
    for p, col in [("lru", COL["lru"]), ("random", COL["random"]), ("snapkv", COL["snapkv"])]:
        pts = []
        for c in budgets:
            cand = {r: mean(cell[(c, r, p)]) - mean(cell[(c, 0.0, p)])
                    for r in rhos if (c, r, p) in cell}
            if not cand:
                continue
            best = max(cand, key=lambda r: cand[r])
            k = min(int(math.ceil(best * c)), c // 2)
            pts.append((xs[c], gy + h_ - min(k, maxk) / maxk * h_))
        s.append(pl(pts, col, 2.4))
        for x, y in pts:
            s.append(f"<circle cx='{x:.1f}' cy='{y:.1f}' r='4' fill='{col}'/>")
    s.append(txt(gx + w_ / 2, gy + h_ + 40, "capacity C (tokens)", 11, "middle", fill="#333"))
    s.append(f"<text x='{gx-46}' y='{gy+h_/2}' {FONT} font-size='10' fill='#444' "
             f"transform='rotate(-90 {gx-46} {gy+h_/2})' text-anchor='middle'>optimal slots per side</text>")
    lx = 90
    for p in ["lru", "random", "snapkv"]:
        s.append(f"<line x1='{lx}' y1='{h_+110}' x2='{lx+20}' y2='{h_+110}' stroke='{COL[p]}' stroke-width='2.4'/>")
        s.append(txt(lx + 25, h_ + 114, p, 10)); lx += 90
    s.append("</svg>")
    open(out, "w").write("\n".join(s))

def fig_mech(cell, mass, dense, out):
    xs_, ys_, cs = [], [], []
    for (c, r, p), d in cell.items():
        for it, v in d.items():
            m_ = mass[(c, r, p)].get(it)
            if it in dense and m_ is not None:
                xs_.append(m_); ys_.append(v - dense[it])
                cs.append(c)
    gx, gy, w_, h_ = 90, 70, W - 220, 250
    lo, hi = min(xs_) - .02, max(xs_) + .02
    ylo, yhi = min(ys_) - .3, max(ys_) + .3
    s = [f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{h_+150}' viewBox='0 0 {W} {h_+150}'>",
         f"<rect width='100%' height='100%' fill='#fff'/>",
         txt(14, 24, "Damage vs retained attention mass: monotone but far from deterministic", 15, weight="bold"),
         axe(gx, gy, gx + w_, gy + h_)]
    for j in range(5):
        v = ylo + (yhi - ylo) * j / 4
        y = gy + h_ - (v - ylo) / (yhi - ylo) * h_
        s.append(f"<line x1='{gx}' y1='{y:.1f}' x2='{gx+w_}' y2='{y:.1f}' stroke='#eee'/>")
        s.append(txt(gx - 6, y + 4, f"{v:.0f}", 9, "end", fill="#666"))
    for j in range(5):
        v = lo + (hi - lo) * j / 4
        x = gx + (v - lo) / (hi - lo) * w_
        s.append(txt(x, gy + h_ + 18, f"{v:.1f}", 10, "middle", fill="#666"))
    cmap = {b: f"hsla({200 - 30 * i},70%,45%,0.35)" for i, b in enumerate(sorted(set(cs)))}
    for x, y, c in zip(xs_, ys_, cs):
        px = gx + (x - lo) / (hi - lo) * w_
        py = gy + h_ - (y - ylo) / (yhi - ylo) * h_
        s.append(f"<circle cx='{px:.1f}' cy='{py:.1f}' r='1.7' fill='{cmap[c]}'/>")
    s.append(txt(gx + w_ / 2, gy + h_ + 40, "retained attention mass of the gold answer", 11, "middle", fill="#333"))
    s.append(f"<text x='{gx-48}' y='{gy+h_/2}' {FONT} font-size='10' fill='#444' "
             f"transform='rotate(-90 {gx-48} {gy+h_/2})' text-anchor='middle'>change in log-prob vs dense</text>")
    lx = 90
    for c in sorted(set(cs)):
        s.append(f"<circle cx='{lx}' cy='{h_+110}' r='4' fill='{cmap[c]}'/>")
        s.append(txt(lx + 9, h_ + 114, f"C={c}", 10)); lx += 70
    s.append("</svg>")
    open(out, "w").write("\n".join(s))

if __name__ == "__main__":
    tag = sys.argv[1] if len(sys.argv) > 1 else "main_q05"
    path = f"{RES}/{tag}.jsonl"
    rows, dense, cell, mass = load(path)
    os.makedirs("./figures", exist_ok=True)
    fd = "./figures"
    fig_rho(cell, dense, f"{fd}/{tag}_fig1_protection.svg")
    fig_cap(cell, dense, f"{fd}/{tag}_fig2_capacity.svg")
    spans = [r["struct_span"] for r in rows if r["policy"] == "dense" and r["struct_span"] > 0]
    fig_rule(cell, f"{fd}/{tag}_fig3_rule.svg", spans)
    fig_mech(cell, mass, dense, f"{fd}/{tag}_fig4_mechanism.svg")
    print("figures ->", fd, "spans", len(spans), "cells", len(cell))
