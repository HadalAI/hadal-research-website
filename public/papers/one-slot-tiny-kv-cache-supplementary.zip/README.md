# Reproducibility bundle

One Slot Is All You Need: Structural Protection in Tiny KV Caches

Everything in the paper's tables and figures is derived from `results/*.jsonl` by the
scripts here. No number in the paper was typed by hand.

## What is here

| path | role |
|---|---|
| `harness.py` | the KV-cache harness: loads a model, slices the cache to a retained position set, scores the gold answer |
| `run_grid.py` | the C x rho x policy grid runner that writes `results/main_*.jsonl` |
| `verify.py`, `verify_sets.py` | the exactness checks (sliced cache vs from-scratch vs additive mask; set-identity of StreamingLLM and LRU at rho = 0.5) |
| `sink_mass.py` | position-0 attention-mass measurement (`results/mass_q05.jsonl`) |
| `analyze.py`, `analyze_mc.py`, `extra.py` | paired bootstrap CIs, headroom, ceiling, spread compression |
| `audit.py` | re-derives every numeric cell of the paper's tables from the JSONL and diffs against the manuscript (235 checks) |
| `make_figs.py` | regenerates the four figures as SVG from the JSONL |
| `check_*.py` | the manuscript-side checks (table values vs source, headline tokens, page limits, fonts/embedded-glyph audit) |
| `results/` | raw logs: 4,968 Qwen2.5-0.5B (item, cell) rows, 4,340 SmolLM2-360M rows, mass and 4-way-accuracy arms |
| `figures/` | the SVG sources of Figures 1-4 |

## Running it

The scripts were written in a working directory and use paths relative to the
bundle root after a mechanical rewrite; they expect to be run from the bundle root.
Python 3.14 with `torch` (CPU) and `transformers`; the models are
`Qwen/Qwen2.5-0.5B-Instruct` and `HuggingFaceTB/SmolLM2-360M-Instruct` in fp32.
The grid was run on 2 vCPU (aarch64) with no GPU.

    python3 verify.py            # exactness checks first, before any number
    python3 run_grid.py          # the grid (8-16 CPU-hours)
    python3 audit.py             # re-derive the tables

## Honest limits

* The bundle is the code that produced the paper, not a maintained package: the
  path rewrite above has not been re-executed end to end, and the figure scripts
  expect `rsvg-convert` to turn SVG into PDF.
* One LongBench item was dropped from the Qwen grid (its cells were lost to a
  crash); every reported cell therefore has n = 23 and the dropped item is named
  in `results/`.
* The 4-way multiple-choice accuracy arm covers 48 cells x 8 items, which is a
  rank-agreement check (Spearman 0.83), not a per-capacity effect estimate.
