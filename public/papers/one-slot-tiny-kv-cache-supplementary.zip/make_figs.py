"""Venue-grade figures for the tiny-KV-cache paper.

Re-plots the same series that paper_figs.py drew, but with geometry expressed in
points and a font scale tied to the output width, so that the text stays
legible at the width the figure is actually placed at:

  * 240 pt  -> 3.33 in  (one column of a two-column venue)
  * 460 pt  -> 6.39 in  (text width of a single-column preprint)

Every number comes from the raw JSONL; nothing is transcribed by hand.
"""
import json, math, os, random
from collections import defaultdict

RES = "/root/.hermes/kanban/workspaces/t_999fe53c/results"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "svg")
os.makedirs(OUT, exist_ok=True)

BLUE, ORANGE, GREEN, VERM, PURPLE, GREY, BLACK = (
    "#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#777777", "#111111")
COL = {"lru": VERM, "random": PURPLE, "h2o": BLUE, "snapkv": GREEN,
       "slw": ORANGE, "oracle": BLACK, "dense": GREY}
CS = [8, 16, 32, 64, 128, 256]
RHOS = [0.0, 0.05, 0.1, 0.2, 0.3, 0.5]
DEP = ("lru", "h2o", "snapkv", "random", "slw")


# --------------------------------------------------------------- data helpers
def per_token(r):
    return sum(r["logprobs"]) / r["n_ans_tokens"] / len(r["logprobs"])


def load(tag):
    rows = [json.loads(l) for l in open(f"{RES}/{tag}.jsonl")]
    g, mass = defaultdict(dict), {}
    for r in rows:
        k = "dense" if r["policy"] == "dense" else (r["C"], r["policy"], round(r["rho"], 3))
        g[r["item_key"]][k] = per_token(r)
        if r["policy"] != "dense":
            mass[(r["item_key"], r["C"], r["policy"], round(r["rho"], 3))] = r["mass_retained"]
    full = sorted(k for k, v in g.items()
                  if all((C, p, r) in v for C in CS for p in DEP + ("oracle",) for r in RHOS))
    return g, full, mass


def cm(g, full, C, p, r):
    return sum(g[i][(C, p, r)] for i in full) / len(full)


def boot(diffs, n=10000, seed=0):
    rng = random.Random(seed)
    bs = sorted(sum(rng.choice(diffs) for _ in diffs) / len(diffs) for _ in range(n))
    return sum(diffs) / len(diffs), bs[250], bs[9750]


# ------------------------------------------------------------------- canvas
class Fig:
    """Tiny SVG canvas in points: viewBox units == points at 1:1 placement."""

    def __init__(self, w, h, base=240.0):
        self.w, self.h = w, h
        self.k = w / base          # font/lineweight scale
        self.s = [f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}pt' "
                  f"height='{h}pt' viewBox='0 0 {w} {h}'>",
                  f"<rect width='100%' height='100%' fill='#fff'/>"]
        self.lw = lambda z: max(0.4, z * self.k)

    def txt(self, x, y, s, size=7.0, anchor="start", weight="normal", fill="#222", rot=None):
        r = f" transform='rotate({rot} {x:.2f} {y:.2f})'" if rot is not None else ""
        esc = (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
        self.s.append(
            f"<text x='{x:.2f}' y='{y:.2f}' font-family='Nimbus Sans,Helvetica,sans-serif' "
            f"font-size='{size*self.k:.2f}' text-anchor='{anchor}' font-weight='{weight}' "
            f"fill='{fill}'{r}>{esc}</text>")

    def line(self, x1, y1, x2, y2, col="#333", w=0.5, dash=None, opacity=1.0):
        da = f" stroke-dasharray='{dash}'" if dash else ""
        self.s.append(f"<line x1='{x1:.2f}' y1='{y1:.2f}' x2='{x2:.2f}' y2='{y2:.2f}' "
                      f"stroke='{col}' stroke-width='{self.lw(w):.2f}' opacity='{opacity}'{da}/>")

    def path(self, pts, col, w=1.1, dash=None):
        d = "M " + " L ".join(f"{x:.2f},{y:.2f}" for x, y in pts)
        da = f" stroke-dasharray='{dash}'" if dash else ""
        self.s.append(f"<path d='{d}' fill='none' stroke='{col}' "
                      f"stroke-width='{self.lw(w):.2f}'{da}/>")

    def dot(self, x, y, col, r=1.5, opacity=1.0):
        self.s.append(f"<circle cx='{x:.2f}' cy='{y:.2f}' r='{r*self.k:.2f}' "
                      f"fill='{col}' opacity='{opacity}'/>")

    def rect(self, x, y, w, h, col, opacity=1.0):
        self.s.append(f"<rect x='{x:.2f}' y='{y:.2f}' width='{w:.2f}' height='{h:.2f}' "
                      f"fill='{col}' opacity='{opacity}'/>")

    def save(self, name):
        self.s.append("</svg>")
        open(f"{OUT}/{name}.svg", "w").write("\n".join(self.s))


class Axes:
    def __init__(self, f, x0, y0, w, h, xlo, xhi, ylo, yhi):
        self.f, self.x0, self.y0, self.w, self.h = f, x0, y0, w, h
        self.xlo, self.xhi, self.ylo, self.yhi = xlo, xhi, ylo, yhi

    def X(self, v):
        return self.x0 + (v - self.xlo) / (self.xhi - self.xlo) * self.w

    def Y(self, v):
        v = max(self.ylo, min(self.yhi, v))
        return self.y0 + self.h - (v - self.ylo) / (self.yhi - self.ylo) * self.h

    def frame(self, xticks=None, yticks=None, xlab=None, ylab=None, grid=True):
        f = self.f
        if grid and yticks:
            for v, lab in yticks:
                y = self.Y(v)
                f.line(self.x0, y, self.x0 + self.w, y, "#ececec", 0.4)
                f.txt(self.x0 - 2.5, y + 2.2, lab, 6.3, "end", fill="#555")
        if grid and xticks:
            for v, lab in xticks:
                x = self.X(v)
                f.line(x, self.y0, x, self.y0 + self.h, "#f4f4f4", 0.4)
                f.txt(x, self.y0 + self.h + 7.5, lab, 6.3, "middle", fill="#333")
        f.line(self.x0, self.y0 + self.h, self.x0 + self.w, self.y0 + self.h, "#333", 0.6)
        f.line(self.x0, self.y0, self.x0, self.y0 + self.h, "#333", 0.6)
        if xlab:
            f.txt(self.x0 + self.w / 2, self.y0 + self.h + 15.0, xlab, 7.0, "middle", fill="#333")
        if ylab:
            f.txt(self.x0 - 22.0, self.y0 + self.h / 2, ylab, 7.0, "middle", fill="#333", rot=-90)

    def zero(self, y=0.0):
        self.f.line(self.x0, self.Y(y), self.x0 + self.w, self.Y(y), "#999", 0.5, "2,2")


def legend(f, items, y, x0, width=None, size=6.6, gap=5.0, lead=8.2):
    """Left-aligned legend that wraps to further rows when it would overflow.

    y is the baseline of the *first* row; wrapping adds rows below it, so
    callers pass the top row and reserve vertical space for it.
    """
    x, row = x0, 0
    for lab, col, dash, kind in items:
        tw = size * 0.52 * len(lab)
        wid = 10.0 + tw + gap
        if width is not None and x > x0 and x + wid - gap > x0 + width:
            x, row = x0, row + 1
        yy = y + row * lead
        if kind == "line":
            f.line(x, yy - 2.2, x + 7.0, yy - 2.2, col, 1.0, dash)
        else:
            f.dot(x + 3.5, yy - 2.2, col, 1.4)
        f.txt(x + 10.0, yy, lab, size)
        x += wid


# ------------------------------------------------------------------ Figure 1
MARK = {"lru": "o", "random": "s", "h2o": "^", "snapkv": "D"}


def marker(f, x, y, col, kind="o", r=1.6):
    if kind == "o":
        f.dot(x, y, col, r)
    elif kind == "s":
        d = r * 0.95
        f.s.append(f"<rect x='{x-d:.2f}' y='{y-d:.2f}' width='{2*d:.2f}' height='{2*d:.2f}' "
                   f"fill='{col}'/>")
    elif kind == "^":
        d = r * 1.25
        f.s.append(f"<path d='M {x:.2f},{y-d:.2f} L {x+d:.2f},{y+d*0.8:.2f} "
                   f"L {x-d:.2f},{y+d*0.8:.2f} Z' fill='{col}'/>")
    else:
        d = r * 1.3
        f.s.append(f"<path d='M {x:.2f},{y-d:.2f} L {x+d:.2f},{y:.2f} L {x:.2f},{y+d:.2f} "
                   f"L {x-d:.2f},{y:.2f} Z' fill='{col}'/>")


def fig1(W=240.0):
    g, full, _ = load("main_q05")
    H = W * 0.72
    f = Fig(W, H)
    ax = Axes(f, 0.17 * W, 0.10 * H, 0.78 * W, 0.72 * H, 0, 5, -1.6, 7.8)
    xt = [(i, str(C)) for i, C in enumerate(CS)]
    yt = [(v, f"{v:.0f}") for v in range(0, 8)]
    ax.frame(xt, yt, "cache capacity C (tokens)", "gain over unprotected (\u0394LP)")
    ax.zero(0)
    for p in ("lru", "random", "h2o", "snapkv"):
        pts, bars = [], []
        for i, C in enumerate(CS):
            d = [g[i2][(C, p, 0.1)] - g[i2][(C, p, 0.0)] for i2 in full]
            m, a, b = boot(d)
            x = ax.X(i)
            pts.append((x, ax.Y(m)))
            bars.append((x, ax.Y(b), ax.Y(a)))
        for x, ya, yb in bars:
            f.line(x, ya, x, yb, COL[p], 0.9, opacity=0.55)
            for yy in (ya, yb):
                f.line(x - 1.3, yy, x + 1.3, yy, COL[p], 0.9, opacity=0.55)
        f.path(pts, COL[p], 1.0)
        for x, y in pts:
            marker(f, x, y, COL[p], MARK[p], 1.7)
    legend(f, [("LRU", COL["lru"], None, "line"), ("random", COL["random"], None, "line"),
               ("H2O", COL["h2o"], None, "line"), ("SnapKV", COL["snapkv"], None, "line")],
           H - 9.5, 0.14 * W, width=0.72 * W, size=6.5)
    f.save("fig1_gain" if W < 300 else "fig1_gain_wide")


# ------------------------------------------------------------------ Figure 2
def fig2(W=240.0):
    H = W * (1.24 if W >= 300 else 1.03)
    f = Fig(W, H)
    panels = [("main_q05", "Qwen2.5-0.5B (S = 48)", -16.4), ("main_smol", "SmolLM2-360M (S = 160)", -17.2)]
    ph = (0.295 if W >= 300 else 0.305) * H
    for pi, (tag, lab, ymin) in enumerate(panels):
        g, full, _ = load(tag)
        y0 = 0.085 * H + pi * (ph + 0.115 * H)
        ax = Axes(f, 0.155 * W, y0, 0.80 * W, ph, 0, 5, ymin, -7.2)
        xt = [(i, str(C)) for i, C in enumerate(CS)]
        yt = [(v, f"{v:.0f}") for v in range(-16, -7, 2)] if pi == 0 else [(v, f"{v:.0f}") for v in range(-16, -7, 2)]
        ax.frame(xt, yt, "capacity C", "gold-answer log-prob / token" if pi == 0 else None)
        dense = sum(g[i]["dense"] for i in full) / len(full)
        f.line(ax.x0, ax.Y(dense), ax.x0 + ax.w, ax.Y(dense), GREY, 0.7, "3,2")
        f.txt(ax.x0 + ax.w - 1, ax.Y(dense) - 2.5, f"dense {dense:.2f}", 6.0, "end", fill="#666")
        f.txt(ax.x0 + ax.w / 2, y0 - 3.0, lab, 7.2, "middle", weight="bold")
        ser = [(("lru", 0.0), VERM, "3,2"), (("lru", 0.1), VERM, None),
               (("random", 0.1), PURPLE, None), (("slw", 0.0), ORANGE, None),
               (("oracle", 0.05), BLACK, "1.5,1.5")]
        for (p, r), col, dash in ser:
            pts = [(ax.X(i), ax.Y(cm(g, full, C, p, r))) for i, C in enumerate(CS)]
            f.path(pts, col, 1.0, dash)
            for x, y in pts:
                f.dot(x, y, col, 1.2)
    legend(f, [("LRU, no prot.", VERM, "3,2", "line"), ("LRU, 10%", VERM, None, "line"),
               ("random, 10%", PURPLE, None, "line"), ("StreamingLLM", ORANGE, None, "line"),
               ("oracle", BLACK, "1.5,1.5", "line")], H - 20.0, 0.10 * W,
           width=0.80 * W, size=6.2)
    f.txt(0.10 * W, H - 3.5, "dashed grey: dense (no eviction) reference", 6.0, fill="#444")
    f.save("fig2_capacity" if W < 300 else "fig2_capacity_wide")


# ------------------------------------------------------------------ Figure 3
def fig3(W=240.0):
    g, full, _ = load("main_q05")
    H = W * (1.14 if W >= 300 else 1.05)
    f = Fig(W, H)
    # ---- (a) optimal k per side, log axis, markers (bars are meaningless on a
    # log scale starting at k = 1, so the quantity is shown as points)
    ph = (0.36 if W >= 300 else 0.34) * H
    axa = Axes(f, 0.19 * W, 0.085 * H, 0.74 * W, ph, 0, 5, math.log10(0.62), math.log10(260))
    f.txt(0.19 * W, 0.085 * H - 4.5, "(a) optimal reservation size", 7.2, weight="bold")

    def KY(k):
        return axa.y0 + ph - (math.log10(max(k, 1)) - axa.ylo) / (axa.yhi - axa.ylo) * ph

    for v in (1, 2, 4, 8, 16, 32, 64, 128):
        y = KY(v)
        f.line(axa.x0, y, axa.x0 + axa.w, y, "#ececec", 0.4)
        f.txt(axa.x0 - 2.5, y + 2.2, str(v), 6.3, "end", fill="#555")
    f.line(axa.x0, axa.y0 + ph, axa.x0 + axa.w, axa.y0 + ph, "#333", 0.6)
    f.line(axa.x0, axa.y0, axa.x0, axa.y0 + ph, "#333", 0.6)
    yb_hi, yb_lo = KY(49), KY(17)          # larger k sits higher on screen
    f.rect(axa.x0, yb_hi, axa.w, yb_lo - yb_hi, GREEN, 0.20)
    f.txt(axa.x0 + axa.w - 1, yb_hi - 2.2, "structural span 17-49", 6.0, "end", fill="#1d6b4f")
    kn = {}
    for p in ("lru", "random", "snapkv"):
        kn[p] = {}
        for C in CS:
            cand = {r: cm(g, full, C, p, r) - cm(g, full, C, p, 0.0) for r in RHOS[1:]}
            r = max(cand, key=cand.get)
            kn[p][C] = min(math.ceil(r * C), C // 2)
    NUDGE = {"lru": -1.9, "random": 0.0, "snapkv": 1.9}
    for i, C in enumerate(CS):
        cx = axa.x0 + axa.w * (i + 0.5) / len(CS)
        f.txt(cx, axa.y0 + ph + 7.5, str(C), 6.3, "middle", fill="#333")
        for p in ("lru", "random", "snapkv"):
            marker(f, cx + NUDGE[p] * W / 240.0, KY(kn[p][C]), COL[p], MARK.get(p, "o"), 1.7)
    f.txt(axa.x0 + axa.w / 2, axa.y0 + ph + 15.0, "capacity C", 7.0, "middle", fill="#333")
    f.txt(axa.x0 - 20.0, axa.y0 + ph / 2, "optimal slots per side (log scale)", 6.8,
          "middle", fill="#333", rot=-90)

    # ---- (b) flatness in k at C = 8
    y0b = 0.085 * H + ph + 0.155 * H
    axb = Axes(f, 0.19 * W, y0b, 0.74 * W, (0.225 if W >= 300 else 0.21) * H, 0, 3, 4.4, 6.4)
    f.txt(0.19 * W, y0b - 4.5, "(b) at C = 8, k = 1 suffices", 7.2, weight="bold")
    xt = [(i, str(k)) for i, k in enumerate([1, 2, 3, 4])]
    yt = [(v, f"{v:.1f}") for v in (4.4, 4.9, 5.4, 5.9, 6.4)]
    axb.frame(xt, yt, "reserved slots per side k", "\u0394LP over unprotected")
    rho_for_k = {1: 0.05, 2: 0.2, 3: 0.3, 4: 0.5}
    for p in ("lru", "random"):
        pts = []
        for i, k in enumerate([1, 2, 3, 4]):
            r = rho_for_k[k]
            d = [g[i2][(8, p, r)] - g[i2][(8, p, 0.0)] for i2 in full]
            m, a, b = boot(d)
            x = axb.X(i)
            pts.append((x, axb.Y(m)))
            f.line(x, axb.Y(b), x, axb.Y(a), COL[p], 0.9, opacity=0.55)
            for yy in (axb.Y(a), axb.Y(b)):
                f.line(x - 1.2, yy, x + 1.2, yy, COL[p], 0.9, opacity=0.55)
        f.path(pts, COL[p], 1.0)
        for x, y in pts:
            marker(f, x, y, COL[p], MARK[p], 1.6)
    legend(f, [("LRU", COL["lru"], None, "line"), ("random", COL["random"], None, "line")],
           H - 3.0, 0.19 * W, width=0.60 * W, size=6.4)
    f.save("fig3_slots" if W < 300 else "fig3_slots_wide")


# ------------------------------------------------------------------ Figure 4
def fig4(W=240.0):
    g, full, mass = load("main_q05")
    H = W * 0.74
    f = Fig(W, H)
    ax = Axes(f, 0.17 * W, 0.10 * H, 0.78 * W, 0.76 * H, -0.02, 1.02, -14.0, 2.0)
    xt = [(v, "0.0" if abs(v) < 0.006 else f"{v:.1f}") for v in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0)]
    yt = [(v, f"{v:.0f}") for v in (-14, -12, -10, -8, -6, -4, -2, 0)]
    ax.frame(xt, yt, "retained attention mass of the gold answer",
             "change in log-prob vs dense")
    ax.zero(0)
    pts = []
    for i in full:
        for C in CS:
            for p in DEP + ("oracle",):
                for r in RHOS:
                    m = mass.get((i, C, p, round(r, 3)))
                    if m is None:
                        continue
                    pts.append((m, g[i][(C, p, r)] - g[i]["dense"], COL[p]))
    for m, d, col in pts:
        f.dot(ax.X(m), ax.Y(d), col, 0.55, opacity=0.30)
    # decile means
    dec = []
    for j in range(10):
        sel = [d for m, d, _ in pts if j / 10 <= m < (j + 1) / 10]
        if sel:
            dec.append((ax.X(j / 10 + 0.05), ax.Y(sum(sel) / len(sel))))
    f.path(dec, BLACK, 1.3)
    for x, y in dec:
        f.dot(x, y, BLACK, 1.3)
    f.txt(0.72 * W, 0.14 * H, f"n = {len(pts):,}", 6.3, fill="#444")
    f.txt(0.72 * W, 0.14 * H + 8.0, "R\u00b2 = 0.38 (linear)", 6.3, fill="#444")
    f.save("fig4_mass" if W < 300 else "fig4_mass_wide")


if __name__ == "__main__":
    for fn in (fig1, fig2, fig3, fig4):
        fn(240.0)
        fn(460.0)
    print("wrote", sorted(os.listdir(OUT)))
