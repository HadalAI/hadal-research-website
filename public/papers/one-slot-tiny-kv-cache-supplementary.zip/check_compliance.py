#!/usr/bin/env python3
"""Mechanical compliance checks for each venue build.

Reports, per build: page count and page size, embedded fonts (flagging Type 3),
raster images, undefined references/citations in the log, overfull boxes, and
whether the PDF carries line numbers or a review watermark.
"""
import subprocess, re, json, sys

BUILDS = ["arxiv", "tmlr", "icml", "mlsys"]

def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout

report = {}
for v in BUILDS:
    pdf = f"build/{v}/main_{v}.pdf"
    log = f"build/{v}/pass.log"
    info = sh(f"pdfinfo {pdf}")
    fonts = sh(f"pdffonts {pdf}")
    imgs = sh(f"pdfimages -list {pdf}")
    logtxt = open(log, errors="ignore").read()

    pages = int(re.search(r"Pages:\s+(\d+)", info).group(1))
    size = re.search(r"Page size:\s+(.+)", info).group(1).strip()
    fontrows = [l for l in fonts.splitlines()[2:] if l.strip()]
    type3 = [l for l in fontrows if "Type 3" in l]
    notemb = [l for l in fontrows if re.search(r"\bno\b", l.split()[-5:-4][0] if False else l) and " no " in l]
    nimg = max(0, len([l for l in imgs.splitlines()[2:] if l.strip()]))
    undefined = len(re.findall(r"undefined", logtxt))
    overfull = len(re.findall(r"Overfull \\hbox", logtxt))
    underfull = len(re.findall(r"Underfull", logtxt))
    missing_glyph = len(re.findall(r"Missing character", logtxt))
    line_numbers = ("lineno" in logtxt) or bool(re.search(r"^\s*\d{3}\s", sh(f"pdftotext -f 2 -l 2 {pdf} -"), re.M))

    report[v] = {
        "pages": pages, "page_size": size,
        "fonts": len(fontrows), "type3_fonts": len(type3),
        "unembedded_fonts": len(notemb), "raster_images": nimg,
        "undefined_refs_or_cites": undefined,
        "overfull_hboxes": overfull, "underfull": underfull,
        "missing_glyphs": missing_glyph, "line_numbers": line_numbers,
    }
    print(f"{v:6s} pages={pages:3d} size={size} fonts={len(fontrows)} type3={len(type3)} "
          f"raster={nimg} undef={undefined} overfull={overfull} underfull={underfull} "
          f"missing_glyph={missing_glyph} lineno={line_numbers}")

print("\n--- font sample (icml) ---")
print(sh("pdffonts build/icml/main_icml.pdf").strip()[:800])
json.dump(report, open("build/compliance_report.json", "w"), indent=2)
